package kz.eub.dictionaryservice.repository;

import kz.eub.dictionaryservice.model.entity.BeneficiarLocalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BeneficiarLocalRepository extends JpaRepository<BeneficiarLocalEntity, String>, JpaSpecificationExecutor<BeneficiarLocalEntity> {
    List<BeneficiarLocalEntity> findAll();
}