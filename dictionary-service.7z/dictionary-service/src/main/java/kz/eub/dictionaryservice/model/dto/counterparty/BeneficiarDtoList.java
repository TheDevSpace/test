package kz.eub.dictionaryservice.model.dto.counterparty;

import java.util.List;


public record BeneficiarDtoList(
    Long totalElements,
    List<CounterpartyDto> beneficiarDtoList) {}
