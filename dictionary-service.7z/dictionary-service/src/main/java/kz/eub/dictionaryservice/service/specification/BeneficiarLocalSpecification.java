package kz.eub.dictionaryservice.service.specification;

import kz.eub.dictionaryservice.model.entity.BeneficiarEntity;
import kz.eub.dictionaryservice.model.entity.BeneficiarLocalEntity;
import org.springframework.data.jpa.domain.Specification;

public class BeneficiarLocalSpecification {
    public static Specification<BeneficiarLocalEntity> hasName(String name) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("name"), "%"+name+"%");
    }

    public static Specification<BeneficiarLocalEntity> hasInn(String inn) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("inn"), "%"+inn+"%");
    }

    public static Specification<BeneficiarLocalEntity> hasOrgId(String orgId) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(
                root.get("orgId"), orgId);
    }
}
