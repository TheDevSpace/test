package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

import java.util.Set;


@Comment("Организация казахстана")
@Entity
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OrgKz extends Org {
    @Comment("Подписанты")
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "org")
    Set<Contact> contacts;

    @Comment("Идентификатор клиента в старой системе")
    @Column (name = "custid")
    String custId;
}
