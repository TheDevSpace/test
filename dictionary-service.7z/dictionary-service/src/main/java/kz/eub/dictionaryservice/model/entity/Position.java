package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Comment;


@Comment("Справочник должностей. <p/> Справочник корпоративный, меняется редко. <p/> Пример содержимого: <p/> Бухгалтер            | Бухгалтера Директор             | Директора Генеральный директор | Генерального директора")
@Entity
@Table(name = "SBNS_POSITION")
@AttributeOverride(name = "id", column = @Column(length = 400))
public class Position extends BaseEntity {
    private static final long serialVersionUID = -9209071981093668250L;

    @Comment("Должность в именительном падеже")
    @Column(name = "positionnom")
    private String positionNom;

    @Comment("Должность в родительном падеже")
    @Column(name = "positiongen")
    private String positionGen;

    public String getPositionNom() {
        return positionNom;
    }

    public void setPositionNom(String positionNom) {
        this.positionNom = positionNom;
    }

    public String getPositionGen() {
        return positionGen;
    }

    public void setPositionGen(String positionGen) {
        this.positionGen = positionGen;
    }

}
