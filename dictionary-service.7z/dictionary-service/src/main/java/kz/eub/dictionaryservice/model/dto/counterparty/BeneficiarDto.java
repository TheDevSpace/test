package kz.eub.dictionaryservice.model.dto.counterparty;


import com.fasterxml.jackson.annotation.JsonProperty;

public class BeneficiarDto extends CounterpartyDto {

    @JsonProperty("account")
    public String benefAccount;

    @JsonProperty("city")
    public String benefPlace;

    @JsonProperty("name")
    private String benefName;

    @JsonProperty("country")
    public String benefCountryName;

    public String getBenefAccount() {
        return benefAccount;
    }

    public void setBenefAccount(String benefAccount) {
        this.benefAccount = benefAccount;
    }

    public String getBenefPlace() {
        return benefPlace;
    }

    public void setBenefPlace(String benefPlace) {
        this.benefPlace = benefPlace;
    }

    public String getBenefCountryName() {
        return benefCountryName;
    }

    public void setBenefCountryName(String benefCountryName) {
        this.benefCountryName = benefCountryName;
    }

    public String getBenefName() {
        return benefName;
    }

    public void setBenefName(String benefName) {
        this.benefName = benefName;
    }
}