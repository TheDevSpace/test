package kz.eub.dictionaryservice.service.impl;

import com.google.common.reflect.TypeToken;
import kz.eub.dictionaryservice.model.dto.PersonClientOrgDto;
import kz.eub.dictionaryservice.model.dto.counterparty.BeneficiarDto;
import kz.eub.dictionaryservice.model.dto.counterparty.BeneficiarDtoList;
import kz.eub.dictionaryservice.model.dto.counterparty.BeneficiarLocalDto;
import kz.eub.dictionaryservice.model.entity.*;
import kz.eub.dictionaryservice.model.record.payment.EcnpRecord;
import kz.eub.dictionaryservice.repository.*;
import kz.eub.dictionaryservice.service.DictionaryService;
import kz.eub.dictionaryservice.service.specification.BeneficiarLocalSpecification;
import kz.eub.dictionaryservice.service.specification.BeneficiarSpecification;
import kz.eub.dictionaryservice.service.specification.EcnpSpecification;
import kz.eub.dictionaryservice.service.specification.PersonClientOrgSpecification;
import kz.eub.dictionaryservice.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DictionaryServiceImpl implements DictionaryService {


    EcnpRepository ecnpRepository;

    @Autowired
    BeneficiarRepository beneficiarRepository;

    @Autowired
    BeneficiarLocalRepository beneficiarLocalRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    public SbnsConfigurationRepository sbnsConfigRepo;

    @Autowired
    public DictionaryServiceImpl(EcnpRepository ecnpRepository, PersonClientOrgRepository personClientOrgRepository) {
        this.ecnpRepository = ecnpRepository;
        this.personClientOrgRepository = personClientOrgRepository;
    }

    @Override
    public List<EcnpRecord> getEcnp(String filterMessage, String paymentType, Pageable pageable) throws Exception {
        try {
            Specification<ECNP> spec = Specification.where(null);
            spec = spec.and(EcnpSpecification.isActive());
            if (filterMessage != null && !filterMessage.isEmpty()) {
                spec = spec.and(EcnpSpecification.hasCode(filterMessage)).or(EcnpSpecification.hasDescription(filterMessage));
            }

            if (paymentType != null && !paymentType.isEmpty()) {
                String[] paymentKeys = CommonUtil.getEcnpConfigKeys(paymentType);
                if (paymentKeys != null && paymentKeys.length > 1) {
                    SbnsConfiguration sbnsConfig = sbnsConfigRepo.findBySubsystemidAndPartidAndDeletetimeAndArchivetime(paymentKeys[0], paymentKeys[1], 0, 0);
                    if (sbnsConfig != null && !sbnsConfig.getConfiguration().isEmpty()) {
                        spec = spec.and(EcnpSpecification.inCode(sbnsConfig.getConfiguration()));
                    }
                }
            }

            Page<ECNP> pageData = ecnpRepository.findAll(spec, pageable);
            List<EcnpRecord> resut = pageData.getContent().stream().map(
                            r -> new EcnpRecord(r.getCode(), r.getDescription()))
                    .collect(Collectors.toList());
            return resut;
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public BeneficiarDtoList getCounterparty(String filterMessage, String type, String orgId, Pageable pageable) throws Exception {
        try {
            BeneficiarDtoList result;

            if (type == null) {
                Specification<BeneficiarEntity> spec = Specification.where(BeneficiarSpecification.hasOrgId(orgId));
                if (filterMessage != null && !filterMessage.isEmpty()) {
                    spec = spec.and(BeneficiarSpecification.hasCountryName(filterMessage)).or(BeneficiarSpecification.hasName(filterMessage)).or(BeneficiarSpecification.hasCity(filterMessage));
                }

                Page<BeneficiarEntity> pageData = beneficiarRepository.findAll(spec, pageable);
                result = new BeneficiarDtoList(pageData.getTotalElements(), modelMapper.map(pageData.getContent(), new TypeToken<List<BeneficiarDto>>() {
                }.getType()));
            } else {
                Specification<BeneficiarLocalEntity> spec = Specification.where(BeneficiarLocalSpecification.hasOrgId(orgId));
                if (filterMessage != null && !filterMessage.isEmpty()) {
                    spec = spec.and(BeneficiarLocalSpecification.hasInn(filterMessage)).or(BeneficiarLocalSpecification.hasName(filterMessage));
                }

                Page<BeneficiarLocalEntity> pageData = beneficiarLocalRepository.findAll(spec, pageable);
                result = new BeneficiarDtoList(pageData.getTotalElements(), modelMapper.map(pageData.getContent(), new TypeToken<List<BeneficiarLocalDto>>() {
                }.getType()));
            }

            return result;
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    @Autowired
    PersonClientOrgRepository personClientOrgRepository;

    @Override
    public List<PersonClientOrgDto> getMainAccountants(String orgId, String fio, String position, Pageable pageable) throws Exception {
//        log.info("Service method getMainAccountants called with orgId: {}, fio: {}, position: {}", orgId, fio, position);
        try {
            Specification<PersonClientOrg> specification = PersonClientOrgSpecification.hasPositionTypeAndOrgId(position, orgId, fio);
            List<PersonClientOrg> entities = personClientOrgRepository.findAll(specification);

            return entities.stream().map(entity -> {
                PersonClientOrgDto dto = new PersonClientOrgDto();
                dto.setId(entity.getId());
                dto.setPositionName(entity.getPosition().getPositionNom());
                dto.setPersonName(entity.getPersonClient().getName());
                return dto;
            }).collect(Collectors.toList());
        } catch (Exception ex) {
//            log.error("Error occurred while fetching main accountants: {}", ex.getMessage(), ex);
            throw new RuntimeException("Error fetching main accountants", ex);
        }
    }


}