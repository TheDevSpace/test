package kz.eub.dictionaryservice.service;

import kz.eub.dictionaryservice.model.dto.PersonClientOrgDto;
import kz.eub.dictionaryservice.model.dto.counterparty.BeneficiarDtoList;
import kz.eub.dictionaryservice.model.record.payment.EcnpRecord;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DictionaryService {
//    EcnpRecords getOrCreateRecord() throws InterruptedException;
    List<EcnpRecord> getEcnp(String filterMessage, String paymentType, Pageable pageable) throws Exception;

    BeneficiarDtoList getCounterparty(String filterMessage, String type, String orgId, Pageable pageable) throws Exception;
    List<PersonClientOrgDto> getMainAccountants(String orgId, String fio, String position, Pageable pageable) throws Exception;

}
