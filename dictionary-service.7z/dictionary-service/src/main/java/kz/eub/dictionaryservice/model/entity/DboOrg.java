package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import kz.eub.dictionaryservice.consts.Dictionary;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

@Comment("Организация")
@Entity
@Table(name = "SBNS_ORG")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(columnDefinition = "varchar(31) default 'DboOrg'")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DboOrg extends BaseEntity {

    @Comment("ИНН")
    @Column
    String inn;

    @Comment("Сокращенное наименование")
    @Column(length = Dictionary.TEXT350)
    String name;

    @Comment("Полное наименование")
    @Column(length = Dictionary.TEXT1000, name = "fullname")
    String fullName;

    @Comment("Сокращенной международное наименование")
    @Column(length = Dictionary.TEXT1000, name = "internationalname")
    String internationalName;

    @Comment("Список адресов организации")
    @ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JoinColumn(name = "addresscollectionid")
    AddressCollection addressCollection;

    @Comment("Факс")
    @Column
    String fax;

    @Comment("Электронная почта")
    @Column
    String email;

    @Comment("Дополнительная информация")
    @Column(length = Dictionary.TEXT4000)
    String notes;

//    @OrderBy
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "org")
//    @DoNotSerialize(include = "UPG")
//    @DoNotPrint
//    Set<Account> accounts = new HashSet<>();

//    @Comment("идентификатор организации во внешней системе @deprecated временно - потом в модуль адаптации")
//    @Column
//    @org.hibernate.annotations.Index(name = Const.AUTO_GENERATED_NAME)
//    String extId;

    @Comment("Имя")
    @Column(length = Dictionary.TEXT300, name = "firstname")
    String firstName;

    @Comment("Фамилия")
    @Column(length = Dictionary.TEXT300, name = "secondname")
    String secondName;

    @Comment("Отчество")
    @Column(length = Dictionary.TEXT300, name = "thirdname")
    String thirdName;

    @Comment("Дополнительная информация")
    @Column(length = Dictionary.TEXT4000, name = "additionalinfo")
    String additionalInfo;

//    @Comment("Статус организации")
//    @ManyToOne(fetch = FetchType.LAZY)
//    @DoNotSerialize(include = "UPG")
//    StateMachine state;

//    @Comment("Идентификатор типа организации")
//    @ManyToOne(targetEntity = OrgType.class, fetch = FetchType.LAZY)
//    @JoinColumn(name = "ORGTYPEID")
//    @DoNotSerialize(include = "UPG")
//    OrgType orgType;

//    @Comment("Алгоритм нумерации документов")
//    @Column
//    @Enumerated(EnumType.STRING)
//    DocCountAlgorithm docCountAlgorithm;

//    @Comment("Статус организации")
//    StateInfo stateInfo = new StateInfo();
//
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "org")
//    @DoNotSerialize(include = "UPG")
//    @DoNotPrint
//    Set<Card> cards = new HashSet<Card>();

//    @Comment("Идентификатор в ДБО3")
//    @Column(name = "legacyid")
//    Integer legacyId;


//    @Comment("Типы дизайна интерфейса")
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "ORGGROUPDESIGNGUITYPEID")
//    private OrgGroupDesignGUIType orgGroupDesignGUIType;

//    public OrgGroupDesignGUIType getOrgGroupDesignGUIType() {
//        return orgGroupDesignGUIType;
//    }
//
//    public void setOrgGroupDesignGUIType(OrgGroupDesignGUIType orgGroupDesignGUIType) {
//        this.orgGroupDesignGUIType = orgGroupDesignGUIType;
//    }

//    public StateInfo getStateInfo() {
//        if (stateInfo == null) {
//            stateInfo = new StateInfo();
//        }
//        return stateInfo;
//    }
}