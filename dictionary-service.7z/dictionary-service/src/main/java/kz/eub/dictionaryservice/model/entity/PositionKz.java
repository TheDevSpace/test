package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

@Entity
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PositionKz extends Position {

    @Comment("Тип должности")
    @Column(name = "positiontype")
    String positionType;
}
