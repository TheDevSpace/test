package kz.eub.dictionaryservice.model.dto;

public class EcnpDto {
}
