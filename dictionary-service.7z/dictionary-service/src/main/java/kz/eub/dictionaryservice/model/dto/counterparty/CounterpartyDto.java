package kz.eub.dictionaryservice.model.dto.counterparty;


public class CounterpartyDto {

    private String id;

    private boolean visible;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }
}
