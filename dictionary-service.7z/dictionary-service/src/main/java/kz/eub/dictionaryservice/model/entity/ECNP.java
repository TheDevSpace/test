package kz.eub.dictionaryservice.model.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.Index;

@Comment("Справочник ЕКНП")
@Entity
@Table(name = "SBNS_KZ_PAYPURPOSE_CODE")
public class ECNP extends BaseEntity {

    @Comment("Код назначения платежа")
    @Column(length = 3)
    @Index(name = "<auto_generated_name>")
    private String code;

    @Comment("Описание назначения платежа, соответствующее коду")
    @Column(length = 4000)
//    @Type("org.hibernate.type.TextType")
//    @Lob
    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
