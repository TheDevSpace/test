package kz.eub.dictionaryservice.model.dto.counterparty;


public class BeneficiarLocalDto extends CounterpartyDto {
//    public int credit;
//    public int debit;
    public String inn;

    public String name;

//    public int getCredit() {
//        return credit;
//    }
//
//    public void setCredit(int credit) {
//        this.credit = credit;
//    }
//
//    public int getDebit() {
//        return debit;
//    }
//
//    public void setDebit(int debit) {
//        this.debit = debit;
//    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }
}
