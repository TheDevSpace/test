package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import kz.eub.dictionaryservice.annotation.DoNotPrint;
import kz.eub.dictionaryservice.consts.Dictionary;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Entity
@Table(name = "SBNS_ACC_TYPE_ENTITY")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@Comment("Сущность, связывающая типы счетов с другими сущностями")
@Getter
@Setter
public class AccountTypeInEntity extends BaseEntity {

    @Comment("Ссылка на тип счета")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ACC_TYPE_ID")
    @DoNotPrint
    AccountType accType;

    @Comment("Ссылка на сущность")
    @Column(length = Dictionary.TEXT36)
    String entityId;
}