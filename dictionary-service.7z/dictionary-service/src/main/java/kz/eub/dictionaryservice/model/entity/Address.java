package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import kz.eub.dictionaryservice.annotation.DoNotPrint;
import kz.eub.dictionaryservice.consts.Dictionary;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

@Comment("Адрес подразделения (в будущем организации)")
@Entity
@Table(name = "SBNS_ADDRESS")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Address extends BaseEntity {

    private static final long serialVersionUID = 318345158737317387L;

    @Comment("Связь с коллекцией адресов")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ADDRESSCOLLECTIONID")
    @DoNotPrint
    AddressCollection addressCollection;

//    @Comment("Тип адреса")
//    @ManyToOne(targetEntity = AddressType.class, fetch = FetchType.LAZY)
//    @JoinColumn(name = "ADDRESSTYPEID")
//    @DoNotSerialize(include = "UPG")
//    AddressType addressType;

    @Comment("Полный адрес")
    @Column(length = Dictionary.TEXT4000)
    String fullAddress;

//    @Comment("Страна")
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "COUNTRYID")
//    @DoNotSerialize(include = "UPG")
//    Country country;

    @Comment("Почтовый индекс")
    public String zipcode;

    @Comment("Код субъекта РФ")
    @Column(length = Dictionary.TEXT2)
    String subjectCode;

    @Comment("Субъект РФ")
    String subject;

    @Comment("Район")
    String district;

    @Comment("Город")
    String city;

    @Comment("Тип населенного пункта")
    @Column
    String tnp;

    @Comment("Населенный пункт")
    String place;

    @Comment("Улица, проспект, переулок и т.п.")
    String street;

    @Comment("Дом (владение)")
    String house;

    @Comment("Корпус (строение)")
    String building;

    @Comment("Квартира (офис)")
    String flat;

    @Comment("Абонентский ящик")
    @Column(length = Dictionary.TEXT50)
    String aj;

    @Comment("Дополнительная информация")
    @Column(length = Dictionary.TEXT4000)
    String description;
}