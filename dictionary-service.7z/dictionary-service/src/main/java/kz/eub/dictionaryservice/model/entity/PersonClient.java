package kz.eub.dictionaryservice.model.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import kz.eub.dictionaryservice.consts.Dictionary;
import org.hibernate.annotations.Comment;


@Comment("Физическое лицо. Сущность, содержащая атрибуты физического лица ФИО и т.п. <p/> Информация о физическом лице в дальнейшем используется для печати реквизитов в договорах, платежках и т.п.")
@Entity
@Table(name = "SBNS_PERSONCLIENT")
public class PersonClient extends BaseEntity {
    private static final long serialVersionUID = -2119258605382287951L;

    @Comment("Наименование")
    @Column(length = Dictionary.TEXT1024)
    private String name;

    @Comment("Фамилия")
    @Column(name = "namesn")
    private String nameSn;

    @Comment("Имя")
    @Column(name = "namef")
    private String nameF;

    @Comment("Отчество")
    @Column(name = "nameg")
    private String nameG;

    @Comment("СНИЛС")
    @Column(length = 11)
    private String snils;

    @Comment("E-mail")
    @Column(length = Dictionary.TEXT255)
    private String email;

    @Comment("Телефон")
    @Column(length = 100)
    private String phone;

//    @Comment("Внешний идентфикатор")
//    @Column(length = 300)
//    private String extId;

    @Comment("Время нотификации")
    @Column(name = "notifytimefrom")
    private Long notifyTimeFrom;

    @Comment("Время нотификации")
    @Column(name = "notifytimeto")
    private Long notifyTimeTo;

//    @Comment("Идентификатор ДБО3")
//    @Column
//    private Integer legacyId;

//    @Comment("Дополнительные номера телефонов физ лица")
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "personClient")
//    private Set<AdditionalPhone> additionalPhones = new HashSet<>();

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameSn() {
        return nameSn;
    }

    public void setNameSn(String nameSn) {
        this.nameSn = nameSn;
    }

    public String getNameF() {
        return nameF;
    }

    public void setNameF(String nameF) {
        this.nameF = nameF;
    }

    public String getNameG() {
        return nameG;
    }

    public void setNameG(String nameG) {
        this.nameG = nameG;
    }

    public String getSnils() {
        return snils;
    }

    public void setSnils(String snils) {
        this.snils = snils;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

//    public String getExtId() {
//        return extId;
//    }
//
//    public void setExtId(String extId) {
//        this.extId = extId;
//    }

    public Long getNotifyTimeFrom() {
        return notifyTimeFrom;
    }

    public void setNotifyTimeFrom(Long notifyTimeFrom) {
        this.notifyTimeFrom = notifyTimeFrom;
    }

    public Long getNotifyTimeTo() {
        return notifyTimeTo;
    }

    public void setNotifyTimeTo(Long notifyTimeTo) {
        this.notifyTimeTo = notifyTimeTo;
    }

//    public Integer getLegacyId() {
//        return legacyId;
//    }
//
//    public void setLegacyId(Integer legacyId) {
//        this.legacyId = legacyId;
//    }

//    public Set<AdditionalPhone> getAdditionalPhones() {
//        return additionalPhones;
//    }

//    public void setAdditionalPhones(Set<AdditionalPhone> additionalPhones) {
//        this.additionalPhones = additionalPhones;
//    }
}

