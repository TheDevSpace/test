package kz.eub.dictionaryservice.repository;

import kz.eub.dictionaryservice.model.entity.BeneficiarEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BeneficiarRepository extends JpaRepository<BeneficiarEntity, String>, JpaSpecificationExecutor<BeneficiarEntity> {
    List<BeneficiarEntity> findAll();
}