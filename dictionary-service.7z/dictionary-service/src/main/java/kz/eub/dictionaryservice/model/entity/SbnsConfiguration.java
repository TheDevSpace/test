package kz.eub.dictionaryservice.model.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;


@Comment("Конфигурация")
@Entity
@Table(name = "SBNS_CONFIGURATION")
public class SbnsConfiguration extends BaseEntity {

    public String configuration;

    public String subsystemid;

    public String partid;

    public Integer hidden;

    public Integer deletetime;

    public Integer archivetime;

    public String getConfiguration() {
        return configuration;
    }

    public void setConfiguration(String configuration) {
        this.configuration = configuration;
    }

    public String getSubsystemid() {
        return subsystemid;
    }

    public void setSubsystemid(String subsystemid) {
        this.subsystemid = subsystemid;
    }

    public String getPartid() {
        return partid;
    }

    public void setPartid(String partid) {
        this.partid = partid;
    }

    public Integer getHidden() {
        return hidden;
    }

    public void setHidden(Integer hidden) {
        this.hidden = hidden;
    }

    public Integer getDeletetime() {
        return deletetime;
    }

    public void setDeletetime(Integer deletetime) {
        this.deletetime = deletetime;
    }

    public Integer getArchivetime() {
        return archivetime;
    }

    public void setArchivetime(Integer archivetime) {
        this.archivetime = archivetime;
    }
}