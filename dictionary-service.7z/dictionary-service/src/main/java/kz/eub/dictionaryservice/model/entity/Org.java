package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import kz.eub.dictionaryservice.consts.Dictionary;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

import java.util.Date;

@Comment("Организация")
@Entity
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Org extends DboOrg {
    public static final int BEI_CODE_LENGTH = 11;

    private static final long serialVersionUID = -1677339564856366870L;

    // вынесено сюда, чтобы можно было использовать в dbo
    public static final String STATE_USED = "_used";
    public static final String STATE_NOT_USED = "_notUsed";
    public static final String STATE_DRAFT = "_draft";


    @Comment("ОКПО")
    @Column
    String okpo;

    @Comment("ОКТМО")
    @Column
    String okato;

    @Comment("ОГРН")
    @Column(name = "ogrn")
    String ogrn;

    @Comment("Дата постановки на налоговый учёт")
    @Column(name = "regdate")
    Date regdate;

    // todo: перенести в sbrf или удалить
    @Deprecated // по словам И. Агапова
    @Comment("Код участника специальной программы автодилеров")
    @Column(name = "spcode")
    String spCode;

    @Comment("Полное наименование ВК (ПС)")
    @Column(length = Dictionary.TEXT1000, name = "fullnamevc")
    String fullNameVC;

    @Comment("Полное наименование ВК (справки)")
    @Column(length = Dictionary.TEXT1000, name = "fullnamevccert")
    String fullNameVCCert;

//    @Comment("Идентификатор орг правовой формы")
//    @ManyToOne(targetEntity = OrgLawForm.class, fetch = FetchType.LAZY)
//    @JoinColumn(name = "ORGLAWFORMID")
//    @DoNotSerialize(include = "UPG")
//    OrgLawForm orgLawForm;

//    @OrderBy
//    @Comment("Список КПП у организации")
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "org")
//    Set<OrgKpp> orgKpp = new HashSet<OrgKpp>();

    @Comment("Руководитель")
    @Column(name = "managername")
    String managerName;

    @Comment("Телефоны руководителя")
    @Column(name = "managerphones")
    String managerPhones;

    @Comment("Главный бухгалтер")
    @Column(name = "accountantname")
    String accountantName;

    @Comment("Телефоны главного бухгалтеры")
    @Column(name = "accountantphones")
    String accountantPhones;

//    @Comment("Код организации.")
//    @Column
//    @Index(name = Const.AUTO_GENERATED_NAME)
//    String code;

    @Comment("Выполнялась ли миграция платежных поручений из системы")
    @Column(name = "rpayordermigrated")
    Boolean rPayOrderMigrated;

    @Comment("Экспорт исходящей корреспонденции")
    @Column(name = "exportoutgoing")
    Boolean exportOutgoing;

    // ---------------------------  Поля для поддержки Частных клиентов -------------------------

//    @Comment("Тип организации")
//    @Column
//    @Enumerated(EnumType.STRING)
//    OrganisationType organisationType;

    @Comment("Разрешить редактирование массового платежа")
    @Column(name = "masspayedit")
    Boolean massPayEdit;

    @Comment("Орган Федерального казначейства")
    @Column(name = "federaltreasurybody")
    Boolean federalTreasuryBody;

    @Comment("Идентификатор организации в АСВКБ")
    @Column(length = Dictionary.TEXT20, name = "extasvkbid")
    String extAsvkbId;

    @Comment("BEI - код")
    @Column(length = BEI_CODE_LENGTH, name = "beicode")
    String beiCode;

    @Comment("Время последнего обновления состояния счетов из АБС")
    @Column(name = "lastaccountsupdated")
    Date lastAccountsUpdated;

    @Comment("Время последнего запроса состояния счетов из АБС")
    @Column(name = "lastaccountsrequested")
    Date lastAccountsRequested;

    @Comment("Время последнего запроса карт из АБС")
    @Column(name = "lastcardrequested")
    Date lastCardRequested;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * Возвращает КПП по умолчанию для данной организации
     *
     * @return КПП по умолчанию или null, если такого нет
     */
//    public OrgKpp getDefaultKpp() {
//        for (OrgKpp kpp : getOrgKpp()) {
//            if (kpp.getDef() == Boolean.TRUE) {
//                return kpp;
//            }
//        }
//        return null;
//    }
}
