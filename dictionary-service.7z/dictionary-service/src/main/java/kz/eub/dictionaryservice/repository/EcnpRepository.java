package kz.eub.dictionaryservice.repository;

import kz.eub.dictionaryservice.model.entity.ECNP;
import kz.eub.dictionaryservice.model.record.payment.EcnpRecord;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EcnpRepository extends JpaRepository<ECNP, String>, JpaSpecificationExecutor<ECNP> {
    List<ECNP> findAll();
//    List<ECNP> findAllByFilterMessage(Pageable pageable);

}