package kz.eub.dictionaryservice.consts;

public final class UPGConst {

    public static final String UUID_REGEXP = "[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{12}";

    public static final String UPG_NAMESPACE = "http://upg.sbns.bssys.com/";
    public static final String UPG_REQUEST_XSD = "com/bssys/sbns/integration/upg/model/request.xsd";

    public static final String UPG_AUTHOR = "UPG Service";
    public static final String UPG_TECH_SIGN_USER_NAME = "Банковская подпись (UPG)";

    public static final String STATUS_UNKNOWN = "UNKNOWN";
    public static final String STATUS_INVALID_XML = "INVALID_XML";
    public static final String STATUS_FAIL = "FAIL";

    public static final String HANDLE_RESULT = "HANDLE_RESULT";
    public static final String SOAP_RESPONSE = "SOAP_RESPONSE";
    public static final String ORG = "ORG";
    public static final String CONTRACT_ID = "CONTRACT_ID";
    public static final String UPG_USER = "UPG_USER";
    public static final String UPG_SESSION = "UPG_USER";

    public static final String PARAM_UPG = "upg";
    public static final String UPG = "UPG";
    public static final String UPG_ID = "upgId";

    public static final String NOT_PROCESSED = "<!--NOT PROCESSED YET-->";
    public static final String UNKNOWN_REQUESTID = "<!--UNKNOWN REQUEST-->";
    public static final String NONEXISTENT_SESSION = "<!--NONEXISTENT SESSION-->";
    public static final String EMPTY_REQUEST = "<!--EMPTY REQUEST-->";
}
