package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

@Comment("Тип счета организаций")
@Entity
@Table(name = "SBNS_ACCOUNT_TYPE")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AccountType extends BaseEntity {

    private static final long serialVersionUID = -1917195035951229651L;

    @Comment("Идентификатор типа счета")
    @Column(name = "typeid")
    String typeId;

    @Comment("Сокращенное наименование")
    @Column(name = "shortname")
    String shortName;

    @Comment("Полное наименование")
    @Column(name = "fullname")
    String fullName;

//    @Comment("Маска счета. Поле доступно для редактирования, пользователь должен иметь возможность ввести целое число (длиной не более 20 разрядов), три разделителя (точки) нередактируемы. Если в некой позиции допускается любой символ, то в ней должен быть установлен знак «?». Ввод ограничен: пользователь имеет возможность вводить только цифры.")
//    @Column(length = 23)
//    String accountMask;

//    @Comment("Идентификатор в ДБО3")
//    @Column(name = "legacyId" )
//    Integer legacyId;
//
//    @Comment("Является ли тип счета депозитным")
//    @Column(name = "isdeposit")
//    Boolean isDeposit;
//
//    @Comment("Отображать ли счета данного типа на странице счетов")
//    @Column(name = "showasacc")
//    Boolean showAsAcc;
//
//    @Comment("Отображать ли счета данного типа на странице депозитов")
//    @Column(name = "showasdep")
//    Boolean showAsDep;
//
//    @Comment("Отображать ли счета данного типа в разделе «Реквизиты» в МБК")
//    @Column(name = "mbkshowreq")
//    Boolean mbkShowReq;
//
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "accType")
//    Set<AccountTypeInEntity> entities = new HashSet<>();
}