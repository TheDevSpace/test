package kz.eub.dictionaryservice.consts;

public class Dictionary {
    public static final int TEXT350 = 350;
    public static final int TEXT1000 = 1000;
    public static final int TEXT36 = 36;
    public static final int TEXT4000 = 4000;
    public static final int TEXT2 = 2;
    public static final int TEXT50 = 50;
    public static final int TEXT300 = 300;
    public static final int TEXT20 = 20;
    public static final int TEXT255 = 255;
    public static final int TEXT1024 = 1024;

}
