package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Comment;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

@Comment("Справочник бенефициаров Казахстана")
@Entity
@Table(name = "SBNS_KZ_BENEFICIAR")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class BeneficiarLocalEntity extends BaseEntity {
//    @Comment("Ссылка на Организацию")
//    @ManyToOne(fetch = FetchType.LAZY, optional = true)
//    @JoinColumn(name = "ORGID")
//    private Org org;

    private String orgId;

    @Comment("Наименование бенефициара")
    private String name;

    @Comment("БИН бенефициара")
    private String inn;

    @Comment("Код бенефициара")
    private String kbe;

    @Comment("Комментарий")
    private String description;

//    @Comment("Список счетов бенефициара")
//    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "localBeneficiar")
//    @BatchSize(size = Dictionary.BATCH_SIZE)
//    private Set<LocalBeneficiarAccount> accounts = new LinkedHashSet<LocalBeneficiarAccount>();

    @Comment("Оповестить по SMS")
    @Column
    private Boolean notifyBySMS;

    @Comment("Оповестить по E-mail")
    @Column
    private Boolean notifyByEMail;

//    @Comment("ID получателей оповещений (IP01)")
//    @ManyToOne(optional = true, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    @JoinColumn(name = "IP01Id")
//    @DoNotSerialize
//    private ReviewersNotification infoPayId;

    @Comment("Юридический адрес")
    private String legalAddress;

//    @Comment("Тэги")
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true)
//    @DoNotSerialize
//    @JoinColumn(name = "docId")
//    private Set<DocumentTag> tags = new HashSet<>();

    @Comment("Системный флаг, что сущность проиндексирована в ElasticSearch")
    @Column
    private Boolean indexed;

//    public Org getOrg() {
//        return org;
//    }
//
//    public void setOrg(Org org) {
//        this.org = org;
//    }


    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getKbe() {
        return kbe;
    }

    public void setKbe(String kbe) {
        this.kbe = kbe;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getNotifyBySMS()
    {
        return notifyBySMS;
    }

    public void setNotifyBySMS(Boolean notifyBySMS)
    {
        this.notifyBySMS = notifyBySMS;
    }

    public Boolean getNotifyByEMail()
    {
        return notifyByEMail;
    }

    public void setNotifyByEMail(Boolean notifyByEMail)
    {
        this.notifyByEMail = notifyByEMail;
    }

//    public Set<LocalBeneficiarAccount> getAccounts() {
//        return accounts;
//    }
//
//    public void setAccounts(Set<LocalBeneficiarAccount> accounts) {
//        this.accounts = accounts;
//    }
//
//    public ReviewersNotification getInfoPayId() {
//        return infoPayId;
//    }
//
//    public void setInfoPayId(ReviewersNotification infoPayId) {
//        this.infoPayId = infoPayId;
//    }

    public String getLegalAddress() {
        return legalAddress;
    }

    public void setLegalAddress(String jurAddress) {
        this.legalAddress = jurAddress;
    }

//    public Set<DocumentTag> getTags() {
//        return tags;
//    }
//
//    public void setTags(Set<DocumentTag> tags) {
//        this.tags = tags;
//    }

    public Boolean getIndexed() {
        return indexed;
    }

    public void setIndexed(Boolean indexed) {
        this.indexed = indexed;
    }
}
