package kz.eub.dictionaryservice.controller;

import jakarta.ws.rs.BadRequestException;
import kz.eub.dictionaryservice.model.dto.PersonClientOrgDto;
import kz.eub.dictionaryservice.service.DictionaryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
public class DictionaryController {

    DictionaryService dictionaryService;
    @Autowired
    public DictionaryController(DictionaryService dictionaryService) {
        this.dictionaryService = dictionaryService;
    }

    @GetMapping(value = "/ecnp")
    public ResponseEntity getEcpn(
            @RequestParam(value = "message", required = false) String message,
            @RequestParam(value = "type", required = false) String paymentType,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size
    ) {
        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.asc(("code"))));
            return new ResponseEntity(dictionaryService.getEcnp(message, paymentType, pageable), HttpStatus.OK);
        } catch(Exception ex) {
            return new ResponseEntity(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/counterparties")
    public ResponseEntity getСounterparties(
            @RequestParam(value = "message", required = false) String message,
            @RequestParam(value = "type", required = false) String counterpartyType,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "10") int size,
            @RequestHeader(name = "org-id") String orgId
    ) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            return new ResponseEntity(dictionaryService.getCounterparty(message, counterpartyType, orgId, pageable), HttpStatus.OK);
        } catch(Exception ex) {
            return new ResponseEntity(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/mainAccountants/executor")
    public List<PersonClientOrgDto> getMainAccountants(@RequestHeader("org-id") String orgId,
                                                       @RequestParam(value = "fio", required = false) String fio,
                                                       @RequestParam("position") String position,
                                                       @RequestParam(name = "page", defaultValue = "0") int page,
                                                       @RequestParam(name = "size", defaultValue = "10") int size) {

        try {
//            log.info("Received request to get main accountants with orgId: {}, fio: {}, position: {}, page: {}, size: {}", orgId, fio, position, page, size);

            Pageable pageable = PageRequest.of(page, size);

            return dictionaryService.getMainAccountants(orgId, fio, position, pageable);
        } catch (BadRequestException ex) {
//            log.warn("Bad request: {}", ex.getMessage());
            throw ex;
        } catch (Exception ex) {
//            log.error("An unexpected error occurred: {}", ex.getMessage(), ex);
            throw new RuntimeException("Internal server error occurred.");
        }


    }

}