package kz.eub.dictionaryservice.model.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import kz.eub.dictionaryservice.annotation.DoNotSerialize;
import kz.eub.dictionaryservice.consts.UPGConst;
import org.hibernate.annotations.Comment;



@Comment("Сущность, описывающая уполномоченное лицо организации. <p/> Уполномоченное лицо организации есть совокупность физического лица, должности и организации, в которой это физическое лицо работает. <p/> Данное лицо - является \"официальным\" для банка. Т.е. именно оно будет использоваться при выводе реквизитов документов, подписантов. Именно через него определяются права доступа к документам, и через него определяются полномочия подписи. <p/> <p/> Для каждого физического лица (personClient), указывается организация (org) и должность этого лица в организации (position) <p/> <p/> Коллекция accounts описывает доступные данной персоне счета и организации.")
@Entity
@Table(name = "SBNS_PERSONCLIENTORG")
@DiscriminatorColumn(columnDefinition = "varchar(35 char) default 'PersonClientOrg'")
public class PersonClientOrg extends BaseEntity {
    private static final long serialVersionUID = -3426557987951761616L;

    @Comment("Идентификатор организации")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ORGID")
    @DoNotSerialize(include = UPGConst.UPG)
    private Org org;

    @Comment("Должность")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "POSITIONID")
    @DoNotSerialize(include = UPGConst.UPG)
    @JsonIgnore
    private Position position;

    @Comment("Идентификатор физического лица")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PERSONCLIENTID")
    @DoNotSerialize(include = UPGConst.UPG)
    @JsonIgnore
    private PersonClient personClient;

//    @Comment("Идентификатор контракта")
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "CONTRACTID")
//    @DoNotSerialize(include = UPGConst.UPG)
//    private DBOContract dboContract;

//    @OrderBy
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "pco")
//    private Set<PersonClientOrgAcc> accounts = new HashSet<PersonClientOrgAcc>();
//
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "pco")
//    @DoNotSerialize(include = UPGConst.UPG)
//    private Set<PersonClientOrgCard> cards = new HashSet<>();

//    @OrderBy
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "personClientOrg")
//    private Set<SignAuthority> signAuthorities = new HashSet<SignAuthority>();
//
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "personClientOrg")
//    @DoNotSerialize(include = UPGConst.UPG)
//    private Set<UserPerson> users = new HashSet<UserPerson>();

//    @OrderBy
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "personClientOrg")
//    @DoNotSerialize(include = UPGConst.UPG)
//    private Set<PersonClientOrgCryptoProfile> cryptoProfiles = new HashSet<PersonClientOrgCryptoProfile>();

    @Comment("Запрет услуги")
    @Column(name = "servicerestriction")
    private Boolean serviceRestriction;

//    @OrderBy
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true, mappedBy = "personClientOrg")
//    private Set<PersonClientOrgServicePackage> services = new HashSet<PersonClientOrgServicePackage>();

    @Comment("Внешний идентификатор")
    @Column(name = "extid")
    private String extId;

//    @Comment("ID пользователя в УЦ")
//    @Column(name = "caid")
//    private String caId;

//    @Comment("Идентификатор ДБО3")
//    @Column(name = "legacyid")
//    private Integer legacyId;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

//    public Org getOrg() {
//        return org;
//    }

//    public void setOrg(Org org) {
//        this.org = org;
//    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

//    public boolean addPersonClientOrgAcc(PersonClientOrgAcc pcoa) {
//        pcoa.setPco(this);
//        return getAccounts().add(pcoa);
//    }

    public PersonClient getPersonClient() {
        return personClient;
    }

    public void setPersonClient(PersonClient personClient) {
        this.personClient = personClient;
    }

//    public Set<PersonClientOrgAcc> getAccounts() {
//        return accounts;
//    }
//
//    public void setAccounts(Set<PersonClientOrgAcc> accounts) {
//        this.accounts = accounts;
//    }
//    public Set<PersonClientOrgCard> getCards() {
//        return cards;
//    }
//    public void setCards(Set<PersonClientOrgCard> cards) {
//        this.cards = cards;
//    }
//    public Set<UserPerson> getUsers() {
//        return users;
//    }
//    public void setUsers(Set<UserPerson> users) {
//        this.users = users;
//    }
//    public Set<SignAuthority> getSignAuthorities() {
//        return signAuthorities;
//    }
//    public void setSignAuthorities(Set<SignAuthority> signAuthorities) {
//        this.signAuthorities = signAuthorities;
//    }
//    public DBOContract getDboContract() {
//        return dboContract;
//    }
//    public void setDboContract(DBOContract dboContract) {
//        this.dboContract = dboContract;
//    }

    public Boolean getServiceRestriction() {
        return serviceRestriction;
    }

    public void setServiceRestriction(Boolean serviceRestriction) {
        this.serviceRestriction = serviceRestriction;
    }

//    public Set<PersonClientOrgServicePackage> getServices() {
//        return services;
//    }
//    public void setServices(Set<PersonClientOrgServicePackage> services) {
//        this.services = services;
//    }
//    public Set<PersonClientOrgCryptoProfile> getCryptoProfiles() {
//        return cryptoProfiles;
//    }
//    public void setCryptoProfiles(Set<PersonClientOrgCryptoProfile> cryptoProfiles) {
//        this.cryptoProfiles = cryptoProfiles;
//    }

    public String getExtId() {
        return extId;
    }

    public void setExtId(String extId) {
        this.extId = extId;
    }

//    public String getCaId() {
//        return caId;
//    }

}