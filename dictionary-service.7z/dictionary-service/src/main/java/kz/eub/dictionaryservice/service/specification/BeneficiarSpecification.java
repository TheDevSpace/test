package kz.eub.dictionaryservice.service.specification;

import kz.eub.dictionaryservice.model.entity.BeneficiarEntity;
import org.springframework.data.jpa.domain.Specification;

public class BeneficiarSpecification {
    public static Specification<BeneficiarEntity> hasName(String benefName) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("benefName"), "%"+benefName+"%");
    }

    public static Specification<BeneficiarEntity> hasOrgId(String orgId) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(
                root.get("orgId"), orgId);
    }

    public static Specification<BeneficiarEntity> hasCountryName(String benefCountryName) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("benefCountryName"), "%"+benefCountryName+"%");
    }

    public static Specification<BeneficiarEntity> hasCity(String benefPlace) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("benefPlace"), "%"+benefPlace+"%");
    }
}
