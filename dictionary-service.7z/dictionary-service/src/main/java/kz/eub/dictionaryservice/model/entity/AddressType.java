package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

@Comment("Тип адреса организаций")
@Entity
@Table(name = "SBNS_ADDRESS_TYPE")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddressType extends BaseEntity {

    private static final long serialVersionUID = 3474511834896469560L;

    public static final String ACTUAL = "actual";
    public static final String JURIDICAL = "juridical";
    public static final String POST = "post";
    public static final String INTERNATIONAL = "international";
    public static final String USRLE = "USRLE";
    public static final String REGISTRATION = "registration";
    public static final String LIVING = "living";

    @Comment("Системное имя типа адреса")
    @Column(name = "systemName")
    String systemName;

    @Comment("Наименование типа адреса")
    @Column(name = "name")
    String name;

    @Comment("Описание")
    @Column(name = "description")
    String description;
}