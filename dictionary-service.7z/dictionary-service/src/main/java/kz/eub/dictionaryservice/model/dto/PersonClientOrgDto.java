package kz.eub.dictionaryservice.model.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

public class PersonClientOrgDto {
    private String id;
    private String positionName;
    private String personName;

    public PersonClientOrgDto(String id, String positionName, String personName) {
        this.id = id;
        this.positionName = positionName;
        this.personName = personName;
    }

    public PersonClientOrgDto() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }
}
