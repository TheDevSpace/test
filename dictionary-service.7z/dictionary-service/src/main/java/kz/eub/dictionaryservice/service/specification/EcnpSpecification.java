package kz.eub.dictionaryservice.service.specification;

import kz.eub.dictionaryservice.model.entity.ECNP;
import org.springframework.data.jpa.domain.Specification;

import java.util.Arrays;

public class EcnpSpecification {
    public static Specification<ECNP> hasCode(String code) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("code"), "%"+code+"%");
    }
    public static Specification<ECNP> hasDescription(String description) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.like(
                root.get("description"), "%"+description+"%");
    }

    public static Specification<ECNP> isActive() {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(
                root.get("deleteTime"), 0L);
    }

    public static Specification<ECNP> inCode(String dataIn) {
        System.out.println("dataIn = " + dataIn);
        String[] inCode = new String[]{dataIn};
        if(dataIn.contains(",")) {
            inCode = dataIn.replace(", ", ",").split(",");
        }
        String[] finalInCode = inCode;
        return (root, query, criteriaBuilder) -> criteriaBuilder.in(root.get("code")).value(Arrays.asList(finalInCode));
    }
}
