package kz.eub.dictionaryservice.repository;


import kz.eub.dictionaryservice.model.entity.PersonClientOrg;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonClientOrgRepository extends JpaRepository<PersonClientOrg, Long>, JpaSpecificationExecutor<PersonClientOrg> {
}