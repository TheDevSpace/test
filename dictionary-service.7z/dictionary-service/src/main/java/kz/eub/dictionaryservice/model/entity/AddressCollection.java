package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

import java.util.HashSet;
import java.util.Set;

@Comment("Коллекции адресов")
@Entity
@Table(name = "SBNS_ADDRESS_COLLECTION")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddressCollection extends BaseEntity {

    private static final long serialVersionUID = 2747782256866786980L;

    @OrderBy
    @OneToMany(fetch = FetchType.EAGER, mappedBy = "addressCollection", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Address> addresses = new HashSet<>();
}