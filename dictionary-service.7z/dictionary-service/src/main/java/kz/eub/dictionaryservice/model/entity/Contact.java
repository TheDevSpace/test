package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;

@Entity
@Table(name = "SBNS_CONTACT")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Contact extends BaseEntity {

    @Comment("Идентификатор организации")
    @ManyToOne(fetch = FetchType.LAZY, targetEntity = OrgKz.class)
    @JoinColumn(name = "ORGNBKID")
    OrgKz org;

    @Comment("Тип должности")
    @ManyToOne
    @JoinColumn(name = "POSITIONID")
    PositionKz position;

    @Comment("ФИО")
    @Column(name = "fullname")
    String fullName;

    @Comment("Телефон")
    @Column(name = "phonenum")
    String phoneNum;

    @Comment("Факс")
    @Column
    String fax;

    @Comment("Электронная почта")
    @Column
    String email;

    @Comment("Комментарий")
    @Column(name = "F_COMMENT")
    String comment;
}
