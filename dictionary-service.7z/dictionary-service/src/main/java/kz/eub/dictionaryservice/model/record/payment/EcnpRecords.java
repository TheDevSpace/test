//package kz.eub.dictionaryservice.model.record.payment;
//
////import lombok.AllArgsConstructor;
////import lombok.Data;
////import lombok.NoArgsConstructor;
//
//import java.time.LocalTime;
//import java.util.List;
//
////@AllArgsConstructor
////@NoArgsConstructor
////@Data
//public record EcnpRecords(List<?> chetamId, LocalTime creationTime) { }