package kz.eub.dictionaryservice.util;

import java.util.HashMap;

public class CommonUtil {

    public static String[] getEcnpConfigKeys(String paymentType) {
        HashMap keys = new HashMap<>(){{
            put("accounts", new String[]{"DBO_CONFIG_SERVICE", "DEP_PAY_PURPOSE_CODES"});
        }};

        return (String[]) keys.get(paymentType);
    }
}
