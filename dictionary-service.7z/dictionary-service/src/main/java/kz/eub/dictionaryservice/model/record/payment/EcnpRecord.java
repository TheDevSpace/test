package kz.eub.dictionaryservice.model.record.payment;

public record EcnpRecord(String code, String description) {
}
