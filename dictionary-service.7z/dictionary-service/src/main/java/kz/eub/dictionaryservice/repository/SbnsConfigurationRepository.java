package kz.eub.dictionaryservice.repository;

import kz.eub.dictionaryservice.model.entity.SbnsConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SbnsConfigurationRepository extends JpaRepository<SbnsConfiguration, String> {
    SbnsConfiguration findByPartid(@Param("partid") String partid);

    SbnsConfiguration findBySubsystemidAndPartid(String subsystemid,String partid);

    SbnsConfiguration findBySubsystemidAndPartidAndDeletetimeAndArchivetime(String subsystemid,String partid, Integer deletetime, Integer archivetime);
}