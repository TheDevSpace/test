package kz.eub.dictionaryservice.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Setter
@Comment("Справочник бенефициаров")
@Entity
@Table(name = "SBNS_BENEFICIAR")
public class BeneficiarEntity extends BaseEntity {

    //Допустимость ввода количества символов для телефона расширена для случая, когда нужно отключить контроль.
    public static final int NOTIFY_PHONE_FIELD_LENGTH = 50;
    public static final int NOTIFY_EMAIL_FIELD_LENGTH = 255;

//    @Column
    @Comment("ID Организация владелец")
    public String orgId;

    // --- Реквизиты бенефициара ---
    @Comment("Наименование бенефициара")
    public String benefName;

    @Comment("Счет бенефициара (IBAN)")
    public String benefAccount;

    @Comment("Международный адрес бенефициара")
    public String benefAddress;

    @Comment("Местонахождение бенефициара")

    public String benefPlace;

    @Comment("Цифровой код страны бенефициара")
    public String benefCountryCode;

    @Comment("mnem02-код страны бенефициара")
    public String benefCountryCode02;

    @Comment("Наименование страны бенефициара")
    public String benefCountryName;


    // --- Реквизиты банка бенефициара ---
    @Comment("Наименование банка бенефициара")
    public String benefBankName;

    @Comment("SWIFT-код банка бенефициара")
    public String benefBankSWIFT;

    @Comment("Клир.код страны банка бенефициара")
    public String beBankClearCountryCode02;

    @Comment("Клир.код банка бенефициара (сокращение)")
    public String beBankClearCodeShort;

    @Comment("Клир.код банка бенефициара (обозначение)")
    public String beBankClearCode02;

    @Comment("Клир.код банка бенефициара (значение)")
    public String beBankClearCode;

    @Comment("Корсчет банка бенефициара")
    public String benefBankCorrAccount;

    @Comment("Адрес банка бенефициара")
    public String benefBankAddress;

    @Comment("Местонахождение банка бенефициара")
    public String benefBankPlace;

    @Comment("Цифровой код страны банка бенефициара")

    public String benefBankCountryCode;

    @Comment("mnem02-код страны банка бенефициара")
    public String benefBankCountryCode02;

    @Comment("Наименование страны банка бенефициара")
    public String benefBankCountryName;


    // --- Реквизиты банка-посредника ---
    @Comment("Наименование банка-посредника")
    public String iMediaBankName;

    @Comment("SWIFT-код банка-посредника")
    public String iMediaBankSWIFT;

    @Comment("Клир.код страны банка-посредника")
    public String iMeBankClearCountryCode02;

    @Comment("Клир.код банка-посредника (сокращение)")
    public String iMeBankClearCodeShort;

    @Comment("Клир.код банка-посредника (обозначение)")
    public String iMeBankClearCode02;

    @Comment("Клир.код банка-посредника (значение)")
    public String iMeBankClearCode;

    @Comment("Адрес банка-посредника")
    public String iMediaBankAddress;

    @Comment("Местонахождение банка-посредника")
    public String iMediaBankPlace;

    @Comment("Цифровой код страны банка-посредника")
    public String iMediaBankCountryCode;

    @Comment("mnem02-код страны банка-посредника")
    public String iMediaBankCountryCode02;

    @Comment("Наименование страны банка-посредника")
    public String iMediaBankCountryName;


    // --- Детали платежа, комиссии и расходы ---
    @Comment("Назначение платежа")
    public String paymentDetails;


    /**
     * ИНН бенефициара
     */
    @Comment("ИНН бенефициара")
    @Column(length = 15)
    public String benefInn;

    /**
     * КПП бенефициара
     */
    @Comment("КПП бенефициара")
    @Column(length = 9)
    public String benefKpp;

    /**
     * Код административной единицы/штата бенефициара
     */
    @Comment("Код административной единицы/штата бенефициара")
    @Column(length = 6)
    public String benefAdminUnitCode;

    /**
     * Наименование административной единицы/штата бенефициара
     */
    @Comment("Наименование административной единицы/штата бенефициара")
    @Column(length = 70)
    public String benefAdminUnitName;

    /**
     * ZIP-код бенефициара
     */
    @Comment("ZIP-код бенефициара")
    @Column(length = 10)
    public String benefZipCode;

    /**
     * Использование в ПП
     */
    @Comment("Использование в ПП")
    @Column
    public Boolean ppInostrCur;

    /**
     * Использование в прочих документах
     */
    @Comment("Использование в прочих документах")
    @Column
    public Boolean otherDocs;


    /**
     * Swift-код бенефициара
     */
    @Comment("Swift-код бенефициара")
    @Column(length = 8)
    public String addInfoSwift;

    /**
     * Опция A для поля 59а (для 103 N/S)
     */
    @Comment("Опция A для поля 59а (для 103 N/S)")
    @Column(length = 1)
    public String option59a;

    /**
     * Отправка платежа (вне/внутри СБРФ)
     */
    @Comment("Отправка платежа (вне/внутри СБРФ)")
    @Column
    public String benefPayment;


    /**
     * Опция A для поля 57а
     */
    @Comment("Опция A для поля 57а")
    @Column(length = 1)
    public String option57a;

    /**
     * Наименование филиала банка бенефициара
     */
    @Comment("Наименование филиала банка бенефициара")
    @Column(length = 140)
    public String benefBankFilialName;

    /**
     * Код административной единицы/штата банка бенефициара
     */
    @Comment("Код административной единицы/штата банка бенефициара")
    @Column(length = 6)
    public String benefBankAdminUnitCode;

    /**
     * Наименование административной единицы/штата банка бенефициара
     */
    @Comment("Наименование административной единицы/штата банка бенефициара")
    @Column(length = 70)
    public String benefBankAdminUnitName;

    /**
     * ZIP-код банка бенефициара
     */
    @Comment("ZIP-код банка бенефициара")
    @Column(length = 10)
    public String benefBankZipCode;

    /**
     * Опция A для поля 56а
     */
    @Comment("Опция A для поля 56а")
    @Column(length = 1)
    public String option56a;

    /**
     * Наименование филиала банка-посредника
     */
    @Comment("Наименование филиала банка-посредника")
    @Column(length = 140)
    public String iMediaBankFilialName;

    /**
     * Код административной единицы/штата банка-посредника
     */
    @Comment("Код административной единицы/штата банка-посредника")
    @Column(length = 6)
    public String iMediaBankAdminUnitCode;

    /**
     * Наименование административной единицы/штата банка-посредника
     */
    @Comment("Наименование административной единицы/штата банка-посредника")
    @Column(length = 70)
    public String iMediaBankAdminUnitName;

    /**
     * ZIP-код банка-посредника
     */
    @Comment("ZIP-код банка-посредника")
    @Column(length = 10)
    public String iMediaBankZipCode;


    /**
     * Код валютной операции
     */
    @Comment("Код валютной операции")
    @Column(length = 5)
    public String operCode;

    /**
     * Описание валютной операции
     */
    @Comment("Описание валютной операции")
    @Column(length = 300)
    public String operCodeDesc;

    /**
     * Комментарии
     */

    @Comment("Комментарии")
    @Column(length = 2000)
    public String addInfoComment;

//    @Comment("Подпись бенефициара")
//    @ManyToOne(optional = true, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    @JoinColumn(name = "signCollectionId")
//    public SignCollection signCollection;

    @Comment("Идентификатор пользователя создавшего/редактировавшего контрагента")
    public String editorId;


    @Comment("ФИО пользователя создавшего/редактировавшего контрагента")
    public String editorName;


    @Comment("Идентификатор пользователя подписавшего контрагента")
    public String signerId;


    @Comment("ФИО пользователя подписавшего контрагента")
    public String signerName;

    @Comment("Оповестить по SMS")
    @Column
    public Boolean notifyBySMS;

    @Comment("Оповестить по e-mail")
    @Column
    public Boolean notifyByEmail;

//    @Comment("Список телефонов для оповещения по SMS")
//    @ElementCollection(fetch = FetchType.EAGER)
//    @Column(name = "PHONE", nullable = false, length = NOTIFY_PHONE_FIELD_LENGTH)
//    @CollectionTable(name = "SBNS_BENEFICIAR_NOTIFY_PHONES", joinColumns = @JoinColumn(name = "BENEFICIARID"))
//    public Set<String> notifyBySMSList;
//
//    @Comment("Список e-mail адресов для оповещения")
//    @ElementCollection(fetch = FetchType.EAGER)
//    @Column(name = "EMAIL", nullable = false, length = NOTIFY_EMAIL_FIELD_LENGTH)
//    @CollectionTable(name = "SBNS_BENEFICIAR_NOTIFY_EMAILS", joinColumns = @JoinColumn(name = "BENEFICIARID"))
//    public Set<String> notifyByEmailList;
//
//    @Comment("Тэги")
//    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.ALL}, orphanRemoval = true)
//    @DoNotSerialize
//    @OrderBy("sysCreateTime")
//    @JoinColumn(name = "docId")
//    public Set<DocumentTag> tags = new LinkedHashSet<>();

    @Comment("Системный флаг, что сущность проиндексирована в ElasticSearch")
    @Column
    public Boolean indexed;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getBenefName() {
        return benefName;
    }

    public void setBenefName(String benefName) {
        this.benefName = benefName;
    }

    public String getBenefAccount() {
        return benefAccount;
    }

    public void setBenefAccount(String benefAccount) {
        this.benefAccount = benefAccount;
    }

    public String getBenefAddress() {
        return benefAddress;
    }

    public void setBenefAddress(String benefAddress) {
        this.benefAddress = benefAddress;
    }

    public String getBenefPlace() {
        return benefPlace;
    }

    public void setBenefPlace(String benefPlace) {
        this.benefPlace = benefPlace;
    }

    public String getBenefCountryCode() {
        return benefCountryCode;
    }

    public void setBenefCountryCode(String benefCountryCode) {
        this.benefCountryCode = benefCountryCode;
    }

    public String getBenefCountryCode02() {
        return benefCountryCode02;
    }

    public void setBenefCountryCode02(String benefCountryCode02) {
        this.benefCountryCode02 = benefCountryCode02;
    }

    public String getBenefCountryName() {
        return benefCountryName;
    }

    public void setBenefCountryName(String benefCountryName) {
        this.benefCountryName = benefCountryName;
    }

    public String getBenefBankName() {
        return benefBankName;
    }

    public void setBenefBankName(String benefBankName) {
        this.benefBankName = benefBankName;
    }

    public String getBenefBankSWIFT() {
        return benefBankSWIFT;
    }

    public void setBenefBankSWIFT(String benefBankSWIFT) {
        this.benefBankSWIFT = benefBankSWIFT;
    }

    public String getBeBankClearCountryCode02() {
        return beBankClearCountryCode02;
    }

    public void setBeBankClearCountryCode02(String beBankClearCountryCode02) {
        this.beBankClearCountryCode02 = beBankClearCountryCode02;
    }

    public String getBeBankClearCodeShort() {
        return beBankClearCodeShort;
    }

    public void setBeBankClearCodeShort(String beBankClearCodeShort) {
        this.beBankClearCodeShort = beBankClearCodeShort;
    }

    public String getBeBankClearCode02() {
        return beBankClearCode02;
    }

    public void setBeBankClearCode02(String beBankClearCode02) {
        this.beBankClearCode02 = beBankClearCode02;
    }

    public String getBeBankClearCode() {
        return beBankClearCode;
    }

    public void setBeBankClearCode(String beBankClearCode) {
        this.beBankClearCode = beBankClearCode;
    }

    public String getBenefBankCorrAccount() {
        return benefBankCorrAccount;
    }

    public void setBenefBankCorrAccount(String benefBankCorrAccount) {
        this.benefBankCorrAccount = benefBankCorrAccount;
    }

    public String getBenefBankAddress() {
        return benefBankAddress;
    }

    public void setBenefBankAddress(String benefBankAddress) {
        this.benefBankAddress = benefBankAddress;
    }

    public String getBenefBankPlace() {
        return benefBankPlace;
    }

    public void setBenefBankPlace(String benefBankPlace) {
        this.benefBankPlace = benefBankPlace;
    }

    public String getBenefBankCountryCode() {
        return benefBankCountryCode;
    }

    public void setBenefBankCountryCode(String benefBankCountryCode) {
        this.benefBankCountryCode = benefBankCountryCode;
    }

    public String getBenefBankCountryCode02() {
        return benefBankCountryCode02;
    }

    public void setBenefBankCountryCode02(String benefBankCountryCode02) {
        this.benefBankCountryCode02 = benefBankCountryCode02;
    }

    public String getBenefBankCountryName() {
        return benefBankCountryName;
    }

    public void setBenefBankCountryName(String benefBankCountryName) {
        this.benefBankCountryName = benefBankCountryName;
    }

    public String getiMediaBankName() {
        return iMediaBankName;
    }

    public void setiMediaBankName(String iMediaBankName) {
        this.iMediaBankName = iMediaBankName;
    }

    public String getiMediaBankSWIFT() {
        return iMediaBankSWIFT;
    }

    public void setiMediaBankSWIFT(String iMediaBankSWIFT) {
        this.iMediaBankSWIFT = iMediaBankSWIFT;
    }

    public String getiMeBankClearCountryCode02() {
        return iMeBankClearCountryCode02;
    }

    public void setiMeBankClearCountryCode02(String iMeBankClearCountryCode02) {
        this.iMeBankClearCountryCode02 = iMeBankClearCountryCode02;
    }

    public String getiMeBankClearCodeShort() {
        return iMeBankClearCodeShort;
    }

    public void setiMeBankClearCodeShort(String iMeBankClearCodeShort) {
        this.iMeBankClearCodeShort = iMeBankClearCodeShort;
    }

    public String getiMeBankClearCode02() {
        return iMeBankClearCode02;
    }

    public void setiMeBankClearCode02(String iMeBankClearCode02) {
        this.iMeBankClearCode02 = iMeBankClearCode02;
    }

    public String getiMeBankClearCode() {
        return iMeBankClearCode;
    }

    public void setiMeBankClearCode(String iMeBankClearCode) {
        this.iMeBankClearCode = iMeBankClearCode;
    }

    public String getiMediaBankAddress() {
        return iMediaBankAddress;
    }

    public void setiMediaBankAddress(String iMediaBankAddress) {
        this.iMediaBankAddress = iMediaBankAddress;
    }

    public String getiMediaBankPlace() {
        return iMediaBankPlace;
    }

    public void setiMediaBankPlace(String iMediaBankPlace) {
        this.iMediaBankPlace = iMediaBankPlace;
    }

    public String getiMediaBankCountryCode() {
        return iMediaBankCountryCode;
    }

    public void setiMediaBankCountryCode(String iMediaBankCountryCode) {
        this.iMediaBankCountryCode = iMediaBankCountryCode;
    }

    public String getiMediaBankCountryCode02() {
        return iMediaBankCountryCode02;
    }

    public void setiMediaBankCountryCode02(String iMediaBankCountryCode02) {
        this.iMediaBankCountryCode02 = iMediaBankCountryCode02;
    }

    public String getiMediaBankCountryName() {
        return iMediaBankCountryName;
    }

    public void setiMediaBankCountryName(String iMediaBankCountryName) {
        this.iMediaBankCountryName = iMediaBankCountryName;
    }

    public String getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(String paymentDetails) {
        this.paymentDetails = paymentDetails;
    }


    public String getBenefInn() {
        return benefInn;
    }

    public void setBenefInn(String benefInn) {
        this.benefInn = benefInn;
    }

    public String getBenefKpp() {
        return benefKpp;
    }

    public void setBenefKpp(String benefKpp) {
        this.benefKpp = benefKpp;
    }

    public String getBenefAdminUnitCode() {
        return benefAdminUnitCode;
    }

    public void setBenefAdminUnitCode(String benefAdminUnitCode) {
        this.benefAdminUnitCode = benefAdminUnitCode;
    }

    public String getBenefAdminUnitName() {
        return benefAdminUnitName;
    }

    public void setBenefAdminUnitName(String benefAdminUnitName) {
        this.benefAdminUnitName = benefAdminUnitName;
    }

    public String getBenefZipCode() {
        return benefZipCode;
    }

    public void setBenefZipCode(String benefZipCode) {
        this.benefZipCode = benefZipCode;
    }

    public Boolean getPpInostrCur() {
        return ppInostrCur;
    }

    public void setPpInostrCur(Boolean ppInostrCur) {
        this.ppInostrCur = ppInostrCur;
    }

    public Boolean getOtherDocs() {
        return otherDocs;
    }

    public void setOtherDocs(Boolean otherDocs) {
        this.otherDocs = otherDocs;
    }

    public String getAddInfoSwift() {
        return addInfoSwift;
    }

    public void setAddInfoSwift(String addInfoSwift) {
        this.addInfoSwift = addInfoSwift;
    }

    public String getOption59a() {
        return option59a;
    }

    public void setOption59a(String option59a) {
        this.option59a = option59a;
    }

    public String getBenefPayment() {
        return benefPayment;
    }

    public void setBenefPayment(String benefPayment) {
        this.benefPayment = benefPayment;
    }

    public String getOption57a() {
        return option57a;
    }

    public void setOption57a(String option57a) {
        this.option57a = option57a;
    }

    public String getBenefBankFilialName() {
        return benefBankFilialName;
    }

    public void setBenefBankFilialName(String benefBankFilialName) {
        this.benefBankFilialName = benefBankFilialName;
    }

    public String getBenefBankAdminUnitCode() {
        return benefBankAdminUnitCode;
    }

    public void setBenefBankAdminUnitCode(String benefBankAdminUnitCode) {
        this.benefBankAdminUnitCode = benefBankAdminUnitCode;
    }

    public String getBenefBankAdminUnitName() {
        return benefBankAdminUnitName;
    }

    public void setBenefBankAdminUnitName(String benefBankAdminUnitName) {
        this.benefBankAdminUnitName = benefBankAdminUnitName;
    }

    public String getBenefBankZipCode() {
        return benefBankZipCode;
    }

    public void setBenefBankZipCode(String benefBankZipCode) {
        this.benefBankZipCode = benefBankZipCode;
    }

    public String getOption56a() {
        return option56a;
    }

    public void setOption56a(String option56a) {
        this.option56a = option56a;
    }

    public String getiMediaBankFilialName() {
        return iMediaBankFilialName;
    }

    public void setiMediaBankFilialName(String iMediaBankFilialName) {
        this.iMediaBankFilialName = iMediaBankFilialName;
    }

    public String getiMediaBankAdminUnitCode() {
        return iMediaBankAdminUnitCode;
    }

    public void setiMediaBankAdminUnitCode(String iMediaBankAdminUnitCode) {
        this.iMediaBankAdminUnitCode = iMediaBankAdminUnitCode;
    }

    public String getiMediaBankAdminUnitName() {
        return iMediaBankAdminUnitName;
    }

    public void setiMediaBankAdminUnitName(String iMediaBankAdminUnitName) {
        this.iMediaBankAdminUnitName = iMediaBankAdminUnitName;
    }

    public String getiMediaBankZipCode() {
        return iMediaBankZipCode;
    }

    public void setiMediaBankZipCode(String iMediaBankZipCode) {
        this.iMediaBankZipCode = iMediaBankZipCode;
    }

    public String getOperCode() {
        return operCode;
    }

    public void setOperCode(String operCode) {
        this.operCode = operCode;
    }

    public String getOperCodeDesc() {
        return operCodeDesc;
    }

    public void setOperCodeDesc(String operCodeDesc) {
        this.operCodeDesc = operCodeDesc;
    }

    public String getAddInfoComment() {
        return addInfoComment;
    }

    public void setAddInfoComment(String addInfoComment) {
        this.addInfoComment = addInfoComment;
    }

//    public SignCollection getSignCollection() {
//        return signCollection;
//    }
//
//    public void setSignCollection(SignCollection signCollection) {
//        this.signCollection = signCollection;
//    }
//
//    public boolean getSigned() {
//        return signCollection != null && !signCollection.getSigns().isEmpty();
//    }

    public String getEditorId() {
        return editorId;
    }

    public void setEditorId(String editorId) {
        this.editorId = editorId;
    }

    public String getEditorName() {
        return editorName;
    }

    public void setEditorName(String editorName) {
        this.editorName = editorName;
    }

    public String getSignerId() {
        return signerId;
    }

    public void setSignerId(String signerId) {
        this.signerId = signerId;
    }

    public String getSignerName() {
        return signerName;
    }

    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    public Boolean getNotifyBySMS() {
        return notifyBySMS;
    }

    public void setNotifyBySMS(Boolean notifyBySMS) {
        this.notifyBySMS = notifyBySMS;
    }

    public Boolean getNotifyByEmail() {
        return notifyByEmail;
    }

    public void setNotifyByEmail(Boolean notifyByEmail) {
        this.notifyByEmail = notifyByEmail;
    }

//    public Set<String> getNotifyBySMSList() {
//        if (notifyBySMSList == null) {
//            notifyBySMSList = new LinkedHashSet<String>();
//        }
//
//        return notifyBySMSList;
//    }
//
//    public void setNotifyBySMSList(Set<String> notifyBySMSList) {
//        this.notifyBySMSList = notifyBySMSList;
//    }
//
//    public Set<String> getNotifyByEmailList() {
//        if (notifyByEmailList == null) {
//            notifyByEmailList = new LinkedHashSet<String>();
//        }
//
//        return notifyByEmailList;
//    }
//
//    public void setNotifyByEmailList(Set<String> notifyByEmailList) {
//        this.notifyByEmailList = notifyByEmailList;
//    }
//
//    public Set<DocumentTag> getTags() {
//        return tags;
//    }
//
//    public void setTags(Set<DocumentTag> tags) {
//        this.tags = tags;
//    }

    public Boolean getIndexed() {
        return indexed;
    }

    public void setIndexed(Boolean indexed) {
        this.indexed = indexed;
    }
}
