package kz.eub.dictionaryservice.service.specification;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import kz.eub.dictionaryservice.model.entity.PersonClient;
import kz.eub.dictionaryservice.model.entity.PersonClientOrg;
import kz.eub.dictionaryservice.model.entity.Position;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Repository
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PersonClientOrgSpecification {


    public static Specification<PersonClientOrg> hasPositionTypeAndOrgId(String positionType, String orgId, String fio) {
        return (root, query, criteriaBuilder) -> {

            Join<PersonClientOrg, Position> positionJoin = root.join("position", JoinType.INNER);
            Join<PersonClientOrg, PersonClient> personClientJoin = root.join("personClient", JoinType.INNER);
            Predicate positionTypePredicate = criteriaBuilder.equal(positionJoin.get("positionType"), positionType);
            Predicate orgIdPredicate = criteriaBuilder.equal(root.get("org").get("id"), orgId);
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(positionTypePredicate);
            predicates.add(orgIdPredicate);
            if (fio != null && !fio.trim().isEmpty()) {
                String searchPattern = "%" + fio + "%";
                Predicate fioPredicate = criteriaBuilder.like(personClientJoin.get("name"), searchPattern);
                predicates.add(fioPredicate);
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}
