package kz.eub.dictionaryservice;

import kz.eub.dictionaryservice.model.entity.ECNP;
import kz.eub.dictionaryservice.model.record.payment.EcnpRecord;
import kz.eub.dictionaryservice.service.impl.DictionaryServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import java.util.List;
import java.util.stream.Collectors;

@ActiveProfiles("test")
@SpringBootTest({"server.port:0", "eureka.client.enabled=false"})
//,
class DictionaryApplicationTests {

/*	@Autowired
	DictionaryServiceImpl dictionaryService;


	@Test
	void contextLoads() {
	}

	@Test
	void test() throws Exception {
		Pageable pageable = PageRequest.of(0, 3, Sort.by(Sort.Order.asc(("code"))));
		List<EcnpRecord> ecnpList = dictionaryService.getEcnp(null, null,  pageable);
		System.out.println("test+++++++++++");
		Assert.isTrue(!ecnpList.isEmpty(), "Ошибка надо проверить подключение к БД");
	}
*/
}
