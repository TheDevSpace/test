//rootProject.name = "dictionary_service"
