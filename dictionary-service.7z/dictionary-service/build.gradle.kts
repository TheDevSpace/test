//plugins {
//	java
//	id("org.springframework.boot") version "3.2.3"
//	id("io.spring.dependency-management") version "1.1.4"
//}
//
//group = "kz.eub"
//version = "0.0.1-SNAPSHOT"
//
//java {
//	sourceCompatibility = JavaVersion.VERSION_21
//}
//
//repositories {
//	mavenLocal()
//	mavenCentral()
///*
//	maven {
//		url = uri("https://nexus.eub.kz/repository/maven-dbo-test-mixed")
//		name = "maven-dbo-test-mixed"
//	}
//*/
//
//	maven {
//		url = uri("https://nexus-dev.eub.kz/repository/maven-public")
//	}
//
//}
////var newDboCommonVersion = "1.0.1"
//
//
//extra["springCloudVersion"] = "2023.0.0"
//
//
//dependencies {
//	implementation("org.springframework.boot:spring-boot-starter:3.2.3")
//	implementation("org.springframework.boot:spring-boot-starter-cache:3.2.3")
//	testImplementation("org.springframework.boot:spring-boot-starter-test:3.2.3")
//	implementation("org.springframework.boot:spring-boot-starter-web:3.2.3")
//	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
//	runtimeOnly("org.postgresql:postgresql")
//	compileOnly("org.projectlombok:lombok:1.18.32")
//	implementation("org.springdoc:springdoc-openapi-starter-webmvc-ui:2.5.0")
//	implementation("org.springframework.cloud:spring-cloud-starter-netflix-eureka-client")
//	implementation("org.springframework.boot:spring-boot-starter-actuator")
//	implementation("io.micrometer:micrometer-observation")
//	implementation("io.micrometer:micrometer-tracing-bridge-brave")
//	implementation("io.zipkin.reporter2:zipkin-reporter-brave")
//	implementation("io.micrometer:micrometer-registry-prometheus")
//	implementation("org.springframework.cloud:spring-cloud-starter-circuitbreaker-resilience4j")
//	implementation("org.springframework.cloud:spring-cloud-starter-bootstrap")
//	implementation("org.springframework.cloud:spring-cloud-starter-config")
//	testImplementation("com.h2database:h2:2.2.224")
//}
//
//dependencyManagement {
//	imports {
//		mavenBom("org.springframework.cloud:spring-cloud-dependencies:${property("springCloudVersion")}")
//	}
//}
//
//tasks.withType<Test> {
//	useJUnitPlatform()
//}
