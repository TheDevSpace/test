package kz.eub.statementservice.model.dto;

import java.math.BigDecimal;

public interface StatementProjection {
    BigDecimal getOutboundBalance();
    BigDecimal getInboundBalance();
    BigDecimal getSumCredit();
    BigDecimal getSumDebit();

}
