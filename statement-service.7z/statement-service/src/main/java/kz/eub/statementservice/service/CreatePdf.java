package kz.eub.statementservice.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;
import kz.eub.statementservice.model.dto.OperationDetailsProjection;
import kz.eub.statementservice.repository.StatementOperationRepository;
import kz.eub.statementservice.utils.fwMoney;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class CreatePdf {

    private static final Logger log = LoggerFactory.getLogger(CreatePdf.class);
    private BaseFont defaultFont = null;
    private BaseFont boldFont = null;

    private final StatementOperationRepository statementOperationRepository;

    public CreatePdf(StatementOperationRepository statementOperationRepository) {
        this.statementOperationRepository = statementOperationRepository;
    }

    private static final String notes = "\n(с указанием наименования товара, выполненных работ, оказанных услуг, номеров и даты товарных документов,\n" +
            "номера и даты договора и иных реквизитов)";
    public byte[] createPdf(String operationId) {
        ByteArrayOutputStream baos = null;
        Document document = null;
        OperationDetailsProjection operationDetail = statementOperationRepository.getStatementOperationDetails(operationId);
        try {
            document = new Document(PageSize.A4.rotate());
            baos = new ByteArrayOutputStream();
            PdfWriter.getInstance(document, baos);
            document.open();
            addParagraph(document, "Поступило в банк-получатель", Font.BOLD, Element.ALIGN_LEFT);
            addParagraph(document, String.format("ПЛАТЕЖНОЕ ПОРУЧЕНИЕ № %s", operationDetail.getDocNumber()), Font.BOLD, Element.ALIGN_CENTER);
//            addParagraph(document, parseDate(operationDetail.getDocDate()), Font.NORMAL, Element.ALIGN_CENTER);
            addParagraph(document, "(дата документа)", Font.NORMAL, Element.ALIGN_CENTER);
            addEmptyLine(document);

            BigDecimal sum = null;
            if (operationDetail.getCredit() != null || operationDetail.getCredit().compareTo(BigDecimal.ZERO) != 0) {
                sum = operationDetail.getCredit();
            } else {
                sum = operationDetail.getDebet();
            }

            fwMoney mo = new fwMoney(sum.longValue());
            String moneyAsString = mo.num2str();

            PdfPTable table1 = new PdfPTable(5);
            table1.setWidthPercentage(100);
            addCellToTable(table1, "Отправитель денег", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getPayerName(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "КОд\n\n" + operationDetail.getPayerOrgType(), 1, 2, Font.NORMAL);
            addCellToTable(table1, "ИИК\n\n"+operationDetail.getPayerAccount(), 1, 2, Font.NORMAL);
            addCellToTable(table1, "СУММА\n\n\n"+sum, 1, 6, Font.NORMAL);
            addCellToTable(table1, "ИИН (БИН)", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getPayerInn(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "Банк отправителя", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getPayerBankName(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "БИК  " + operationDetail.getPayerBankBic(), 2, 1, Font.NORMAL);
            addCellToTable(table1, "Бенефициар", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getBenefName(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "КБе\n\n"+ operationDetail.getBenefOrgType(), 1, 2, Font.NORMAL);
            addCellToTable(table1, "ИИК\n\n"+operationDetail.getBenefAccount(), 1, 2, Font.NORMAL);
            addCellToTable(table1, "ИИН (БИН)", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getBenefInn(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "Банк бенефициара", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getBenefBankName(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "БИК  " + operationDetail.getBenefBankBic(), 2, 1, Font.NORMAL);
            addCellToTable(table1, "Сумма прописью", 1, 1, Font.NORMAL);
            addCellToTable(table1, moneyAsString, 4, 1, Font.NORMAL);
            addCellToTable(table1, "Дата получения товара (оказания услуг)", 2, 1, Font.NORMAL);
            addCellToTable(table1, "", 1, 1, Font.NORMAL);
            addCellToTable(table1, "Код назначения\nплатежа", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getPayPurposeCode(), 1, 1, Font.NORMAL);
            addCellToTable(table1, "Назначение платежа\n" + operationDetail.getPaymentPurpose() + notes, 3, 2, Font.NORMAL);
            addCellToTable(table1, "Код бюджетной\nклассификации", 1, 1, Font.NORMAL);
            addCellToTable(table1, "", 1, 1, Font.NORMAL);
            addCellToTable(table1, "Дата валютирования", 1, 1, Font.NORMAL);
//            addCellToTable(table1, parseDate(operationDetail.getValueDate()), 1, 1, Font.NORMAL);
//            addCellToTable(table1, parseDate(operationDetail.getValueDate()), 1, 1, Font.NORMAL);
            addCellToTable(table1, "В том числе НДС", 1, 1, Font.NORMAL);
            addCellToTable(table1, operationDetail.getNds(), 4, 1, Font.NORMAL);
            document.add(table1);
            addEmptyLine(document);

            Chunk glue = new Chunk(new VerticalPositionMark());
            Paragraph fioParagraph = new Paragraph();
            fioParagraph.add(new Chunk("Руководитель              ", getFont(Font.NORMAL)));
            fioParagraph.add(new Chunk(operationDetail.getExecutive(), getFont(Font.NORMAL)));
            fioParagraph.add(new Chunk(glue));
            fioParagraph.add(new Chunk("Проведено банком-получателем ", getFont(Font.NORMAL)));
            document.add(fioParagraph);

            Paragraph positionParagraph = new Paragraph();
            positionParagraph.add(new Chunk("Главный бухгалтер    ", getFont(Font.NORMAL)));
            positionParagraph.add(new Chunk(operationDetail.getChiefAccountant(), getFont(Font.NORMAL)));
            positionParagraph.add(new Chunk(glue));
            positionParagraph.add(new Chunk("\"    \"                                              20    г.", getFont(Font.UNDERLINE)));
            Paragraph tb = new Paragraph(new Chunk("                                                                   \n", getFont(Font.UNDERLINE)));
            tb.setAlignment(Element.ALIGN_RIGHT);
            positionParagraph.add(tb);
            document.add(positionParagraph);


            document.close();
        } catch (DocumentException | IOException ex) {
            log.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage(), ex);
        } finally {
            if (document != null) {
                document.close();
            }
            try {
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return baos.toByteArray();
    }

    public PdfPCell getCell(String text, int alignment, int fontType) throws DocumentException, IOException {
        defaultFont = BaseFont.createFont("kztimesnewroman.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        Font myFont = new Font();
        if (fontType == 0) {
            myFont = new Font(defaultFont, 11, Font.NORMAL);
        }
        if (fontType == 4) {
            myFont = new Font(defaultFont, 11, Font.UNDERLINE);
        }
        PdfPCell cell = new PdfPCell(new Phrase(text, myFont));
        cell.setPadding(0);
        cell.setHorizontalAlignment(alignment);
        cell.setBorder(PdfPCell.NO_BORDER);
        return cell;
    }


    private void addParagraph(Document document, String text, int fontType, int alignment) throws DocumentException, IOException {
        Paragraph paragraph = new Paragraph(text, getFont(fontType));
        paragraph.setAlignment(alignment);
        document.add(paragraph);
    }

    private void addEmptyLine(Document doc) throws DocumentException {
        doc.add(new Paragraph("\n"));
    }

    private PdfPCell createPdfPCell(String text, int colspan, int rowspan, int fontType) throws DocumentException, IOException {
        PdfPCell cell = new PdfPCell(new Phrase(text, getFont(fontType)));
        cell.setColspan(colspan);
        cell.setRowspan(rowspan);
        cell.setMinimumHeight(30f);
        return cell;
    }

    private void addCellToTable(PdfPTable table, String text, int colspan, int rowspan, int fontType) throws DocumentException, IOException {
        PdfPCell cell = createPdfPCell(text, colspan, rowspan, fontType);
        table.addCell(cell);
    }

    private Font getFont(int fontType) throws DocumentException, IOException {
        if (defaultFont == null)
            defaultFont = BaseFont.createFont("kztimesnewroman.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        if (boldFont == null)
            boldFont = BaseFont.createFont("timesbd.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        switch (fontType) {
            case 0:
                return new Font(defaultFont, 11, Font.NORMAL);
            case 1:
                return new Font(boldFont, 11, Font.NORMAL);
            case 2:
                return new Font(defaultFont, 11, Font.ITALIC);
            case 4:
                return new Font(defaultFont, 11, Font.UNDERLINE);
            default:
                throw new RuntimeException("Font not found");
        }
    }

    private String parseDate(String date) {
        System.out.println("test check -> " + date);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS XXX");
        LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        System.out.println("test check2 -> " + outputFormatter);
        return localDateTime.format(outputFormatter);
    }

}

