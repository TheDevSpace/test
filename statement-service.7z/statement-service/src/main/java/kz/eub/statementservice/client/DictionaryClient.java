package kz.eub.statementservice.client;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import kz.eub.statementservice.model.record.EcnpRecord;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "dictionary-service")
@CircuitBreaker(name= "default")
@Retry(name= "default")
public interface DictionaryClient {
    @GetMapping("/api/dictionary/v1/ecnp")
    List<EcnpRecord> getEcnp(@RequestParam(value = "message", required = false) String message,
                             @RequestParam(value = "type", required = false) String paymentType,
                             @RequestParam(name = "page", defaultValue = "0") int page,
                             @RequestParam(name = "size", defaultValue = "10") int size);
}

