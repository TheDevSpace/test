package kz.eub.statementservice.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "SBNS_KZ_STATEMENT_OPERATIONS")
@AllArgsConstructor
@Getter
@Setter
public class StatementOperation {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(name = "benefname")
    private String benefName;
    @Column(name = "docnumber")
    private String docNumber;
    @Column(name = "payername")
    private String payerName;
    @Column(name = "benefaccountcurrisocode")
    private String benefAccountCurrIsoCode;
    @Column(name = "payeraccountcurrisocode")
    private String payerAccountCurrIsoCode;

    @Column(name = "credit")
    private BigDecimal credit;
    @Column(name = "debet")
    private BigDecimal debet;
    @Column(name = "paymentpurpose")
    private String paymentPurpose;

    @Column(name = "docdate")
    @JsonFormat
            (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDateTime docDate;

    @Column(name = "syscreatetime")
    @JsonFormat
            (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDateTime sysCreateTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "statement_id")
    private Statement statementId;

    //    private Date operationDate;
    //    private String payPurposeCode;
    //    private Date bankAcceptDate;
    //    private String payerInn;
    //    private String payerBankBic;
    //    private String benefInn;
//    private String benefBankBic;
//    private String benefBankCorrAccount;
//    private String benefOrgType;
//    private String operationType;

    //    public int archivetime=0;
    //    public int deletetime=0;
//    public Date syscreatetime;
//    public int version=0;
//    public String additionalinfo;
//    public String benefaccount;
//    public String benefaddress;
//    public String benefbankaddress;
//    public String benefbankshortaddress;
//    public String benefcountryname;
//    public String benefkpp;
//    public String budgetcode;
//    public String chiefaccountant;
//    public String codevo;
//    public String commissionaccount;
//    public String commissiontype;
//    public String contractdate;
//    public String contractnumber;
//    public String contractregnumber;
//    public String creditnat;
//    public String debetnat;
//    public String deductiontype;
//    public String docdate;
//    public String doctype;
//    public String executedby;
//    public String executioncourse;
//    public String executive;
//    public String extdocid;
//    public String intermediarybankaccount;
//    public String intermediarybankaddress;
//    public String intermediarybankbic;
//    public String intermediarybankname;
//    public String intermediarybankplace;
//    public String invoice;
//    public String nds;
//    public String payperiod;
//    public String payeraccount;
//    public String payeraddress;
//    public String payerorgtype;
//    public String payerregion;
//    public String preparedby;
//    public String sgk;
//    public String transactionnumber;
//    public String urgent;
//    public String valuedate;
//    public String vinchk;
//    public String vincode;
//    public String withnds;
//    public String documentid;
//    public String documenttype;




    public StatementOperation() {
    }

}