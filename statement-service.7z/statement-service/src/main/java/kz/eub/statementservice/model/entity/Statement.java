package kz.eub.statementservice.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "SBNS_KZ_STATEMENT")
@Getter
@Setter
@AllArgsConstructor
public class Statement {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(name = "outboundbalance")
    private BigDecimal outboundBalance;
    @Column(name = "inboundbalance")
    public BigDecimal inboundbalance;
    @Column(name = "account")
    private String account;
    @Column(name = "fromdate")
    private LocalDate fromDate;

    public Statement() {

    }


//    public String docnumber;
//    public String bankname;
//    public String accountid;
//    public String accountmanager;
//    public String accountcurrencyisocode;
//    public String accountcurrency;
//    public Date syscreatetime;
//    public int archivetime=0;
//    public int deletetime=0;
//    public int version=0;
//    public String bankbic;
//    public Date createdate;
//    public Date docdate;
//    public String dpd;
//    public String extdocid;
//    public String inboundbalancenat;
//    public int isfinal=1;
//    public Date lastmodifydate;
//    public Date lastoperationdate;
//    public UUID orgid;
//    public String orginn;
//    public String orgname;
//    public String outboundbalancenat;
//    public String prevoperationdate;
//    public String requestid;
//    public String sgk;
//    public Date todate;
//    public BigDecimal totalcredits;
//    public String totalcreditsnat;
//    public BigDecimal totaldebets;
//    public String totaldebetsnat;
//    public String signcollectionid;
//    public String state_id;
//    public int indexed=1;
//    public String seizureamount;
//    public String seizurewholeamount;
//    public String dtype;
//    public String seizureamountrpro;
//    public String seizurewholeamountrpro;


}
