package kz.eub.statementservice.service;

import kz.eub.statementservice.client.DictionaryClient;
import kz.eub.statementservice.model.record.EcnpRecord;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequiredArgsConstructor
public class GetTestFeign {

    DictionaryClient dictionaryClient;

    public List<EcnpRecord> getAll(String message, String paymentType, int page, int size) {
        return dictionaryClient.getEcnp(message, paymentType, page, size);
    }

}
