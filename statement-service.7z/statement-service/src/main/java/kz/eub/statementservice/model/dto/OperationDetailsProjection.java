package kz.eub.statementservice.model.dto;

import java.math.BigDecimal;
import java.util.UUID;

public interface OperationDetailsProjection {
    UUID getId();
    String getAccount();
    String getBic();
    String getBankName();
    String getInn();
    String getKbe();
    String getDocNumber();
    String getDocDate();
    String getValueDate();
    String getNds();
    String getPayerName();
    String getPayerInn();
    String getPayerBankName();
    String getPayerBankBic();
    String getPayerOrgType();
    String getPayerAccount();
    String getBenefAccount();
    String getBenefName();
    String getBenefInn();
    String getBenefBankName();
    String getBenefBankBic();
    String getBenefOrgType();
    String getPaymentPurpose();
    String getPayPurposeCode();
    String getExecutive();
    String getChiefAccountant();
    BigDecimal getDebet();
    BigDecimal getCredit();
}
