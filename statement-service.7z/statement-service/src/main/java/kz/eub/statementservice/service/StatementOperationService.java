package kz.eub.statementservice.service;

import kz.eub.statementservice.model.dto.OperationDetailsProjection;
import kz.eub.statementservice.model.dto.StatementProjection;
import kz.eub.statementservice.model.dto.response.OperationDetailsDto;
import kz.eub.statementservice.model.dto.response.StatementOperationResp;
import kz.eub.statementservice.model.dto.response.StatementResponse;
import kz.eub.statementservice.model.entity.StatementOperation;
import kz.eub.statementservice.repository.StatementOperationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class StatementOperationService {

    private final StatementOperationRepository statementOperationRepository;


    public StatementResponse getStatementOperations(String account, LocalDate fromDate, LocalDate toDate, Pageable pageable, String operationType2, BigDecimal fromSum, BigDecimal toSum, String search) {

        Instant start = Instant.now();

        StatementProjection statementProjection = statementOperationRepository.getStatementOperationDtoByIdV2(fromDate, toDate, account, operationType2);

        Specification<StatementOperation> spec = StatementSpecification.findByStatementCriteria(account, fromDate, toDate, operationType2, fromSum, toSum, search);
        Instant startRepo = Instant.now();
        Page<StatementOperation> pageData = statementOperationRepository.findAll(spec, pageable);
        Instant finishRepo = Instant.now();
        long timeRepoElapsed = Duration.between(startRepo, finishRepo).toMillis();
        log.info("Time repo elapsed: ", timeRepoElapsed);
        List<StatementOperationResp> statementResponse =pageData.getContent().stream()
                .map(statementOperation -> {
                    String receiver;
                    BigDecimal sum;
                    String currencyCode;
                    String operationType;
                    if (statementOperation.getBenefName() != null && !statementOperation.getBenefName().isEmpty()) {
                        receiver = statementOperation.getBenefName();
                    } else {
                        receiver = statementOperation.getPayerName();
                    }
                    if (statementOperation.getCredit() != null) {
                        sum = statementOperation.getCredit();
                        operationType = "credit";
                    } else {
                        sum = statementOperation.getDebet();
                        operationType = "debit";
                    }
                    if (statementOperation.getBenefAccountCurrIsoCode() != null) {
                        currencyCode = statementOperation.getBenefAccountCurrIsoCode();
                    } else {
                        currencyCode = statementOperation.getPayerAccountCurrIsoCode();
                    }
                    return new StatementOperationResp(
                            statementOperation.getId(),
                            statementOperation.getDocNumber(),
                            receiver,
                            currencyCode,
                            sum,
                            statementOperation.getPaymentPurpose(),
                            account,
                            operationType,
                            statementOperation.getDocDate()
                    );
                })
                .collect(Collectors.toList());

        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toMillis();
        log.info("Time elapsed: ", timeElapsed);

        return new StatementResponse(
                statementProjection.getOutboundBalance(),
                statementProjection.getInboundBalance(),
                statementProjection.getSumCredit(),
                statementProjection.getSumDebit(),
                statementResponse);

    }


    public OperationDetailsDto getOperationDetails(String operationId) {

        OperationDetailsProjection operationDetailsProjection = statementOperationRepository.getStatementOperationDetails(operationId);
        OperationDetailsDto operationDetailsDto = new OperationDetailsDto();
        operationDetailsDto.setId(operationDetailsProjection.getId());
        operationDetailsDto.setAccount(operationDetailsProjection.getAccount());
        operationDetailsDto.setBic(operationDetailsProjection.getBic());
        operationDetailsDto.setBankname(operationDetailsProjection.getBankName());
        operationDetailsDto.setInn(operationDetailsProjection.getInn());
        operationDetailsDto.setKbe(operationDetailsProjection.getKbe());
        operationDetailsDto.setDoc_number(operationDetailsProjection.getDocNumber());


        return operationDetailsDto;
    }

}
