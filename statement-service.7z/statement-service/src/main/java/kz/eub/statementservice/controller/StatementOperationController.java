package kz.eub.statementservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import kz.eub.statementservice.model.dto.response.OperationDetailsDto;
import kz.eub.statementservice.model.dto.response.StatementResponse;
import kz.eub.statementservice.service.CreatePdf;
import kz.eub.statementservice.service.StatementOperationService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
public class StatementOperationController {

    private final StatementOperationService statementOperationService;
    private final CreatePdf createPdf;

    @Operation(summary = "Получение выписки по счету")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = String.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "400", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping(value = "/operations", produces = "application/json;charset=UTF-8")
    public StatementResponse getOperationById3(@RequestParam(value = "account") String account,
                                               @RequestParam(value = "from-date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
                                               @RequestParam(value = "to-date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
                                               @RequestParam(name = "page", defaultValue = "0") int page,
                                               @RequestParam(name = "size", defaultValue = "20") int size,
                                               @RequestParam(name = "period", required = false, defaultValue = "") String period,
                                               @RequestParam(name = "search", required = false) String search,
                                               @RequestParam(name = "operation-type", required = false) String operationType,
                                               @RequestParam(name = "from-sum", required = false) BigDecimal fromSum,
                                               @RequestParam(name = "to-sum", required = false) BigDecimal toSum) {

        // Проверка разницы в датах
        long monthsBetween = ChronoUnit.MONTHS.between(fromDate.withDayOfMonth(1), toDate.withDayOfMonth(1));
        if (monthsBetween > 1 || (monthsBetween == 1 && fromDate.getDayOfMonth() < toDate.getDayOfMonth())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Диапазон не должен превышать одного месяца.");
        }

        switch (period) {
            case "today":
                fromDate = LocalDate.now();
                toDate = LocalDate.now();
                break;
            case "week":
                fromDate = LocalDate.now().minusWeeks(1);
                toDate = LocalDate.now();
                break;
            case "month":
                fromDate = LocalDate.now().minusMonths(1);
                toDate = LocalDate.now();
                break;
            default:
                initionalDate(fromDate, toDate);
                break;
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.desc(("sysCreateTime"))));

        StatementResponse statementOperationsPage = statementOperationService.getStatementOperations(account, fromDate, toDate, pageable, operationType, fromSum, toSum, search);;
        return statementOperationsPage;
    }


    public void initionalDate (LocalDate dateFrom, LocalDate dateTo) {
        if (dateFrom == null) {
            dateFrom = LocalDate.now();
        }
        if (dateTo == null) {
            dateTo = LocalDate.now();
        }
    }

    @Operation(summary = "Получение выписки по операциям")
    @GetMapping(value = "/detail", produces = "application/json;charset=UTF-8")
    public OperationDetailsDto getDetail(@RequestParam(value = "operation_id") String operationId) {


        OperationDetailsDto operationDetails = statementOperationService.getOperationDetails(operationId);

        return operationDetails;
    }


    @Operation(summary = "Получение печатной формы")
    @GetMapping(value = "printed-form", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> getOffer(@RequestParam(value = "operation_id") String operationId) {
        byte[] pdf = createPdf.createPdf(operationId);
        ByteArrayInputStream bis = new ByteArrayInputStream(pdf);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=offer.pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
}
