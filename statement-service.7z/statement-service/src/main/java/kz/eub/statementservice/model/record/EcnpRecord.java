package kz.eub.statementservice.model.record;

public record EcnpRecord(String code, String description) {
}