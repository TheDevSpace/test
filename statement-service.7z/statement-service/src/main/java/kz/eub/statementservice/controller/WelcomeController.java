package kz.eub.statementservice.controller;

import kz.eub.statementservice.model.record.EcnpRecord;
import kz.eub.statementservice.service.GetTestFeign;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WelcomeController {

    GetTestFeign getTestFeign;
    @GetMapping("/v1")
    public String welcome() {
        return "Welcome to statement-service!";
    }

    @GetMapping("/v1/test")
    public ResponseEntity<List<EcnpRecord>> testFeign(@RequestParam(value = "message", required = false) String message,
                                                      @RequestParam(value = "type", required = false) String paymentType,
                                                      @RequestParam(name = "page", defaultValue = "0") int page,
                                                      @RequestParam(name = "size", defaultValue = "10") int size) {
        List<EcnpRecord> ecnpRecords = getTestFeign.getAll(message, paymentType, page, size);
        return ResponseEntity.ok(ecnpRecords);
    }
}
