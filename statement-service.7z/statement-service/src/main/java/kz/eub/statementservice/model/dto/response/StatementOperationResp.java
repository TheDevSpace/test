package kz.eub.statementservice.model.dto.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record StatementOperationResp(
        String id,
        String docNumber,
        String receiver,
        String currencyCode,
        BigDecimal sum,
        String paymentPurpose,
        String account,
        String operationType,
        LocalDateTime docDate

) {}
