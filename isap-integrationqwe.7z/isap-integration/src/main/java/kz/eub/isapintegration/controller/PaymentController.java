package kz.eub.isapintegration.controller;

import io.swagger.v3.oas.annotations.Operation;
import kz.eub.isapintegration.constant.PaymentStatus;
import kz.eub.isapintegration.exceptionHandler.PaymentNotFoundException;
import kz.eub.isapintegration.model.dto.request.GetPaymentFullDataRequest;
import kz.eub.isapintegration.model.dto.request.GetPaymentsListRequest;
import kz.eub.isapintegration.model.dto.request.PostNewStatusRequest;
import kz.eub.isapintegration.model.dto.response.GetPaymentFullDataResponse;
import kz.eub.isapintegration.model.dto.response.PostNewStatusResponse;
import kz.eub.isapintegration.model.entity.Payment;
import kz.eub.isapintegration.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import java.util.List;


import kz.eub.isapintegration.model.dto.response.GetPaymentsListResponse;
import kz.eub.isapintegration.model.dto.response.PaymentDto;


@Endpoint
@RequiredArgsConstructor
public class PaymentController {

    private static final String NAMESPACE_URI = "http://localhost:8080/ws/payments";

    private final PaymentService paymentService;

    @Operation(summary = "Get list of payments with awaiting approval status")
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getPaymentsListRequest")
    @ResponsePayload
    public GetPaymentsListResponse getPaymentsList123(@RequestPayload GetPaymentsListRequest request) {
        GetPaymentsListResponse resp = paymentService.getPaymentList();
//        List<Payment> payments = paymentService.getPaymentsByStatus(PaymentStatus.AWAITING_APPROVAL.getCode());
//
//        if (payments.isEmpty()) {
//            throw new PaymentNotFoundException("Payment not found for status: " + PaymentStatus.AWAITING_APPROVAL.getDescription());
//        }
//
//        GetPaymentsListResponse response = new GetPaymentsListResponse();
//        response.getPayments().addAll(payments.stream().map(this::mapToPaymentDto).toList());
//
//        paymentService.updatePaymentStatus(PaymentStatus.AWAITING_APPROVAL.getCode(), PaymentStatus.UNDER_REVIEW.getCode());

        return response;
    }

    private PaymentDto mapToPaymentDto(Payment payment) {
        PaymentDto dto = new PaymentDto();
        dto.setId(payment.getId());
        dto.setAccountId(payment.getAccountId());
        dto.setPaymentType(payment.getPaymentType());
        dto.setSysCreateTime(payment.getSysCreateTime());
        dto.setValueDate(payment.getValueDate());
        dto.setDocNumber(payment.getDocNumber());
        dto.setAmount(payment.getAmount());
        dto.setPayerName(payment.getPayerName());
        dto.setPayerInn(payment.getPayerInn());
        dto.setPayerAccount(payment.getPayerAccount());
        dto.setPayPurposeCode(payment.getPayPurposeCode());
        return dto;
    }


    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getPaymentFullDataRequest")
    @ResponsePayload
    public GetPaymentFullDataResponse getPaymentFullData(@RequestPayload GetPaymentFullDataRequest request) {

        Payment payment = paymentService.getPaymentsByIdAndStatus(request.getId(), PaymentStatus.AWAITING_APPROVAL.getCode());

        if (payment == null) {
            throw new PaymentNotFoundException("Payment not found for ID: " + request.getId());
        }

        GetPaymentFullDataResponse response = new GetPaymentFullDataResponse();

        response.setId(payment.getId());
        response.setAccountId(payment.getAccountId());
        response.setNds(String.valueOf(payment.getNds()));
        response.setPayerBankBic(payment.getPayerBankBic());
        response.setBenefName(payment.getBenefName());
        response.setBenefIin(payment.getBenefInn());
        response.setBenefBankBic(payment.getBenefBankBic());
        response.setBudgetCode(payment.getBudgetCode());
        response.setBenefBankName(payment.getBenefBankName());
        response.setBenefOrgType(payment.getBenefOrgType());
        response.setBranchId(payment.getBranchId());
        response.setPayPurposeCode(payment.getPayPurposeCode());
        response.setPayerAccount(payment.getPayerAccount());
        response.setPaymentPurpose(payment.getPaymentPurpose());
        response.setBenefCountryCode("payment.getBenefcountrycode()");        // Страна банка получателя (Код страны резиденства получателя)
        response.setContractNumber(payment.getContractNumber());
        response.setContractDate(payment.getContractDate());
        response.setPassportNum("payment.getPassportnum()");    //Номер паспорта сделки
        response.setAlonePayment(payment.getAlonePayment());

        paymentService.updatePaymentStatusId(payment.getId(), PaymentStatus.UNDER_REVIEW.getCode());

        return response;
    }



    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "PostNewStatusRequest")
    @ResponsePayload
    public PostNewStatusResponse getPostStatus(@RequestPayload PostNewStatusRequest request) {
        PostNewStatusResponse response = new PostNewStatusResponse();
        String msg = "неизвестный статус"; // Значение по умолчанию

        if (request.getCheckStatus().contains(PaymentStatus.APPROVAL_DENIED.getCode())) {
            msg = PaymentStatus.APPROVAL_DENIED.getDescription();
            paymentService.updatePaymentStatusId(request.getId(), request.getCheckStatus());
        } else if (request.getCheckStatus().contains(PaymentStatus.APPROVED.getCode())) {
            msg = PaymentStatus.APPROVED.getDescription();
            paymentService.updatePaymentStatusId(request.getId(), request.getCheckStatus());
        }

        response.setResult(String.format("SUCCESS PostNewStatus: %s", msg));
        return response;
    }

}