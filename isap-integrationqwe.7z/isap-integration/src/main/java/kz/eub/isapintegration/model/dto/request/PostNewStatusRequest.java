package kz.eub.isapintegration.model.dto.request;

import jakarta.xml.bind.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "id",
        "checkStatus"
})
@XmlRootElement(namespace="http://localhost:8080/ws/payments", name="PostNewStatusRequest")
public class PostNewStatusRequest {

    @XmlElement(namespace = "http://localhost:8080/ws/payments", required = true)
    protected String id;
    @XmlElement(namespace = "http://localhost:8080/ws/payments", required = true)
    protected String checkStatus;

}