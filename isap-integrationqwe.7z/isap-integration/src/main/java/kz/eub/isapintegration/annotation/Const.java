package kz.eub.isapintegration.annotation;

import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

public final class Const {
//    public static final TimeZone SERVER_TIME_ZONE;
//    public static final DateTimeFormatter DATE_FORMATTER;
    public static final int TEXT36 = 36;
    public static final int TEXT64 = 64;
    public static final int TEXT256 = 256;
    public static final int TEXT500 = 500;
    public static final int TEXT512 = 512;
    public static final int TEXT4000 = 4000;
    public static final int MAX_MONEY_LENGTH = 20;
    public static final int MEGABYTE = 1048576;
    public static final int KILOBYTE = 1024;
    public static final String FIELD_DELETE_TIME = "deleteTime";
    public static final String FIELD_ARCHIVE_TIME = "archiveTime";
//    public static final Long DEFAULT_ARCHIVE_TIME;
//    public static final Long DEFAULT_DELETE_TIME;
    public static final String SYS_ACTION_CREATE = "_create";
    public static final String SYS_ACTION_EDIT = "_edit";
    public static final String SYS_ACTION_SHOW = "_show";
    public static final String SYS_ACTION_COPY = "_copy";
    public static final String SYS_ACTION_SAVE = "_save";
    public static final String SYS_ACTION_SAVE_NO_CLOSE = "_saveNoClose";
    public static final String SYS_ACTION_SAVE_MANUAL_CLOSE = "_saveManualClose";
    public static final String SYS_ACTION_SAVE_CREATE = "_saveCreate";
    public static final String SYS_ACTION_CLOSE = "_close";
    public static final String SYS_ACTION_CHECK = "_check";
    public static final String SYS_ACTION_SEND_TO_ARCHIVE = "_send_to_archive";
    public static final String SYS_ACTION_RETURN_FROM_ARCHIVE = "_return_from_archive";
    public static final String SYS_ACTION_PRINT = "_print";
    public static final String SYS_ACTION_HELP = "_help";
    public static final String SYS_ACTION_DELETE = "_delete";
    public static final String SYS_ACTION_RESTORE = "_restore";
    public static final String SYS_ACTION_SCROLLER_TO_EXCEL = "_scrollerToExcel";
    public static final String SYS_ACTION_SCROLLER_TO_PDF = "_scrollerToPdf";
    public static final String SYS_ACTION_SCROLLER_TO_RTF = "_scrollerToRtf";
    public static final String SYS_ACTION_REFRESH = "_refresh";
    public static final String SYS_ACTION_GRID_CREATE = "_gridCreate";
    public static final String SYS_ACTION_GRID_COPY = "_gridCopy";
    public static final String SYS_ACTION_GRID_EDIT = "_gridEdit";
    public static final String SYS_ACTION_GRID_DELETE = "_gridDelete";
    public static final String SYS_ACTION_GRID_SHOW = "_gridShow";
    public static final String INTERCALL_CLOSE = "INTERCALL_CLOSE";
    public static final String SYS_ACTION_FORM_SWITCH = "_switchForm";
    public static final String SYS_ALL_ACTIONS = "allActions";
    public static final String SYS_TREE_PARENT_FIELD = "_treeParentField";
    public static final String PARAM_DOCUMENT_ID = "id";
    public static final String PARAM_STATE_COMMENT = "stateComment";
    public static final String PARAM_STATE_HISTORY_USER = "stateHistoryUser";
    public static final String PARAM_VALIDATION_RESULT = "validationResult";
    public static final String PARAM_VALIDATION_ERROR = "validationError";
    public static final String PARAM_VALIDATION_HAS_ERROR = "validationHasError";
    public static final int BATCH_SIZE = 999;
    public static final String AUTO_GENERATED_NAME = "<auto_generated_name>";
//    public static final AllowedChars ONLY_DIGITS;
//    public static final AllowedChars COLOR_FORMAT;
//    public static final AllowedChars FOR_KPP;
//    public static final AllowedChars FOR_BENEF_ACC;
//    public static final AllowedChars FOR_KPP_WS;
//    public static final AllowedChars FOR_INTERNATIONAL;
//    public static final AllowedChars FOR_INTERNATIONAL_CAPITAL_ONLY;
//    public static final AllowedChars FOR_INTERNATIONAL_AND_NEW_LINE;
//    public static final AllowedChars FOR_PDC_OUT;
//    public static final AllowedChars FOR_PDC_IN;
    public static final String RESTART_GATE_QUEUE_NAME = "GATE.RESTART";
    public static final String EXPORT = "_export";
    public static final String TRANSFORM = "_transform";
    public static final String ASK_STATE = "_ask_state";
    public static final String DOCID = "docId";
    public static final String DOCUMENT = "doc";
    public static final String DEFAULT = "_default";
    public static final String ORGID = "orgId";
    public static final String JAVA_IO_TMPDIR = "java.io.tmpdir";
    public static final String ERROR = "Ошибка";
    public static final String NEW_LINE = "\r\n";
    public static final String PARAM_SEND_ERROR = "sendError";
    public static final String PARAM_SEND_WARNING = "sendWarning";
    public static final String LOGIN_HTML_URL = "html/login.html";
    public static final String ALT_LOGIN_HTML_URL = "html/altlogin.html";
    public static final String AUTOLOGIN_HTML_URL = "autoLoginEnter";
    public static final String AUTOLOGIN_URL = "../service/autoLogin";
    public static final String PROCESS_STATE_MACHINE_POSTFIX = ".ProcessStateMachine";
    public static final String PROCESS_SM_VERSION_SEPARATOR = ".";

//    static {
//        SERVER_TIME_ZONE = DateFormats.SERVER_TIME_ZONE;
//        DATE_FORMATTER = DateTimeFormat.forPattern("dd.MM.yyyy").withLocale(Locale.ENGLISH).withZone(DateTimeZone.forTimeZone(SERVER_TIME_ZONE));
//        DEFAULT_ARCHIVE_TIME = 0L;
//        DEFAULT_DELETE_TIME = DEFAULT_ARCHIVE_TIME;
//        ONLY_DIGITS = new AllowedChars("[0-9]*", "Допустимые символы: 0123456789");
//        COLOR_FORMAT = new AllowedChars("[a-fA-F0-9#]*", "Допустимые символы: #0123456789ABCDEFabcdef");
//        FOR_KPP = new AllowedChars("[0123456789QWERTYUIOPASDFGHJKLZXCVBNM]*", "Допустимые символы: 0123456789 QWERTYUIOPASDFGHJKLZXCVBNM");
//        FOR_BENEF_ACC = new AllowedChars("[0123456789QWERTYUIOPASDFGHJKLZXCVBNM(),./:-]*", "Допустимые символы: 0123456789 QWERTYUIOPASDFGHJKLZXCVBNM/-().,:");
//        FOR_KPP_WS = new AllowedChars("[0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm]*", "Допустимые символы: 0123456789 QWERTYUIOPASDFGHJKLZXCVBNM qwertyuiopasdfghjklzxcvbnm");
//        FOR_INTERNATIONAL = new AllowedChars("[QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890 '()+,./:?\\-\\&]*", "Допустимые символы: QWERTYUIOPASDFGHJKLZXCVBNMqwertyuio pasdfghjklzxcvbnm 1234567890 '()+,./:?-&");
//        FOR_INTERNATIONAL_CAPITAL_ONLY = new AllowedChars("[QWERTYUIOPASDFGHJKLZXCVBNM1234567890 '()+,./:?-]*", "Допустимые символы: QWERTYUIOPASDFGHJKLZXCVBNM 1234567890 '()+,./:?-");
//        FOR_INTERNATIONAL_AND_NEW_LINE = new AllowedChars("[0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '/()+,\\-.:;?\r\n\\&]*", "Допустимые символы: 0123456789ABCDEFGHIJKLMNOPQRSTUVWX\nYZabcdefghijklmnopqrstuvwxyz '/()+,-.:;?&");
//        FOR_PDC_OUT = new AllowedChars("[QWERTYUIOPASDFGHJKLZXCVBNM1234567890 '()+,./:?-]*", "Допустимые символы: 0123456789 QWERTYUIOPASDFGHJKLZXCVBNM'()+,./:?-");
//        FOR_PDC_IN = new AllowedChars("[ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ QWERTYUIOPASDFGHJKLZXCVBNM1234567890 '()+,./:?]*", "Допустимые символы: 0123456789 QWERTYUIOPASDFGHJKLZXCVBNM ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ'()+,./:?-");
//    }

    private Const() {
    }

    public static enum ErrorLevel {
        CRITICAL_ERROR,
        ERROR,
        WARNING,
        INFO;

        private ErrorLevel() {
        }
    }

    public static enum FileFormat {
        TXT("txt"),
        EML("eml"),
        BIN("bin");

        private String ext;

        private FileFormat(String ext) {
            this.ext = ext;
        }

        public String getExt() {
            return this.ext;
        }
    }
}