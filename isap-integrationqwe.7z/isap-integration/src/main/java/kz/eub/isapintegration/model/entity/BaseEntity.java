package kz.eub.isapintegration.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Version;
import lombok.Data;
import org.hibernate.annotations.Comment;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@MappedSuperclass
@Data
public abstract class BaseEntity implements Serializable {
    @Comment("Идентификатор объекта")
    @Id
    @Column(
            length = 36
    )
    private String id;
    @Version
    @Comment("Системная (hibernate) версия объекта")
    private Integer version;
    @Comment("Системное время создания")
    @Column(name = "SYSCREATETIME")
    private Date sysCreateTime;
//    @Comment("Дата архивирования")
//    @Column
//    private Long archiveTime;
//    @Comment("Дата удаления")
//    @Column
//    private Long deleteTime;

    public BaseEntity() {
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o != null && this.getClass() == o.getClass()) {
            BaseEntity that = (BaseEntity)o;
            return Objects.equals(this.id, that.id);
        } else {
            return false;
        }
    }

    public int hashCode() {
        return this.id != null ? this.id.hashCode() : 0;
    }

    public String toString() {
        return this.getClass().getSimpleName() + ":" + this.id;
    }
}

