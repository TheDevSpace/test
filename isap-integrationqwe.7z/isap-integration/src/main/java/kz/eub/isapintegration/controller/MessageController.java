package kz.eub.isapintegration.controller;


import kz.eub.isapintegration.constant.PaymentStatus;
import kz.eub.isapintegration.exceptionHandler.PaymentNotFoundException;
import kz.eub.isapintegration.model.dto.response.GetPaymentsListResponse;
import kz.eub.isapintegration.model.dto.response.PaymentDto;
import kz.eub.isapintegration.model.entity.Payment;
import kz.eub.isapintegration.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MessageController {

    @Autowired
    private JmsTemplate jmsTemplate;

    @GetMapping("/send")
    public String sendMessage() {
        String message = "Привет, ActiveMQ!";
        jmsTemplate.convertAndSend("MyQueue", message);
        return "Сообщение отправлено!";
    }

    @GetMapping("/send2")
    public String sendMessage2() {
        String message = "<?xml version=\"1.1\" encoding=\"UTF-8\"?>\n" +
                "<StateResponse xmlns:i=\"http://bssys.com/sbns/integration\"\n" +
                "               xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                "               xsi:schemaLocation=\"http://bssys.com/sbns/integration schema.xsd\">\n" +
                "       <createTime>2024-08-01T11:11:38.108+05:00</createTime>\n" +
                "       <docType>KzPayment</docType>\n" +
                "       <docId>01902aeb-70e1-11cc-accd-f8ca5d5e2cd5</docId>\n" +
                "       <state>test</state>\n" +
                "       <bankMessage/>\n" +
                "       <messageOnlyForBank/>\n" +
                "    </StateResponse>";
        jmsTemplate.convertAndSend("CC_Output", message);
        return "Сообщение отправлено!";
    }


    @Autowired
    private PaymentService paymentService;
    @GetMapping("/getPaymentListRequest")
    public GetPaymentsListResponse sendMessage3() {
        List<Payment> payments = paymentService.getPaymentsByStatus(PaymentStatus.AWAITING_APPROVAL.getCode());

        if (payments.isEmpty()) {
            throw new PaymentNotFoundException("Payment not found for status: " + PaymentStatus.AWAITING_APPROVAL.getDescription());
        }

        GetPaymentsListResponse response = new GetPaymentsListResponse();
        response.getPayments().addAll(payments.stream().map(this::mapToPaymentDto).toList());

        paymentService.updatePaymentStatus(PaymentStatus.AWAITING_APPROVAL.getCode(), PaymentStatus.UNDER_REVIEW.getCode());

        return response;
    }

    private PaymentDto mapToPaymentDto(Payment payment) {
        PaymentDto dto = new PaymentDto();
        dto.setId(payment.getId());
        dto.setAccountId(payment.getAccountId());
        dto.setPaymentType(payment.getPaymentType());
        dto.setSysCreateTime(payment.getSysCreateTime());
        dto.setValueDate(payment.getValueDate());
        dto.setDocNumber(payment.getDocNumber());
        dto.setAmount(payment.getAmount());
        dto.setPayerName(payment.getPayerName());
        dto.setPayerInn(payment.getPayerInn());
        dto.setPayerAccount(payment.getPayerAccount());
        dto.setPayPurposeCode(payment.getPayPurposeCode());
        return dto;
    }
}