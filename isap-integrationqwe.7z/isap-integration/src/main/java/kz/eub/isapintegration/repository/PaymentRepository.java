package kz.eub.isapintegration.repository;

import kz.eub.isapintegration.model.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Integer> {

    @Query("SELECT p FROM Payment p " +
            "JOIN StateMachine sm ON sm.id = p.state.id " +
            "WHERE p.currentstatenamesys = 'rejectedSanction' " +
            "AND p.checkStatus = :status " +
            "AND sm.currentStateNameSys = 'rejectedSanction'")
    List<Payment> findByCheckStatus(String status);

    @Modifying
    @Query("UPDATE Payment p SET p.checkStatus = :newStatus WHERE p.checkStatus = :oldStatus")
    void updateStatus(@Param("oldStatus") String oldStatus,
                      @Param("newStatus") String newStatus);

    @Query("SELECT p FROM Payment p " +
            "JOIN StateMachine sm ON sm.id = p.state.id " +
            "WHERE p.id = :id " +
            "AND p.currentstatenamesys = 'rejectedSanction' " +
            "AND p.checkStatus = :status " +
            "AND sm.currentStateNameSys = 'rejectedSanction'")
    Payment findByIdAndCheckStatus(@Param("id") String id,
                                   @Param("status") String status);
    @Modifying
    @Query("UPDATE Payment p SET p.checkStatus = :newStatus WHERE p.id = :paymentId")
    void findByIdAndUpdateCheckStatus(@Param("paymentId") String paymentId, @Param("newStatus") String newStatus);

}
