package kz.eub.isapintegration.model.dto.response;

import jakarta.xml.bind.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "id",
        "accountId",
        "nds",
        "payerBankBic",
        "benefName",
        "benefIin",
        "benefBankBic",
        "budgetCode",
        "benefBankName",
        "benefOrgType",
        "branchId",
        "payPurposeCode",
        "payerAccount",
        "paymentPurpose",
        "benefCountryCode",
        "contractNumber",
        "contractDate",
        "passportNum"
//        "alonePayment"
})
@XmlRootElement(namespace = "http://localhost:8080/ws/payments", name = "getPaymentFullDataResponse")
public class GetPaymentFullDataResponse {

    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String id;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String accountId;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String nds;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String payerBankBic;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String benefName;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String benefIin;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String benefBankBic;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String budgetCode;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String benefBankName;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String benefOrgType;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String branchId;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String payPurposeCode;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String payerAccount;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String paymentPurpose;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String benefCountryCode;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String contractNumber;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected Date contractDate;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected String passportNum;
    @XmlElement(namespace="http://localhost:8080/ws/payments", required = true)
    protected int alonePayment;
}