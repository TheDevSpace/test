package kz.eub.isapintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
public class IsapIntegrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(IsapIntegrationApplication.class, args);
    }

}
