package kz.eub.isapintegration.model.entity;

import jakarta.persistence.*;
import kz.eub.isapintegration.annotation.Const;
import kz.eub.isapintegration.annotation.DoNotSerialize;
import kz.eub.isapintegration.annotation.FieldSize;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import java.math.BigDecimal;
import java.util.Date;


@Comment("Платежный документ")
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "SBNS_KZ_PAYMENT")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Payment extends BaseEntity {

    private static final long serialVersionUID = 1214151907637549278L;

    public static final String BUDGET = "budget";
    public static final String SOCIAL = "social";
    public static final String PENSION = "pension";
    public static final String SALARY = "salary";
    public static final String TOTAL = "total";
    public static final String ORDER = "order";
    public static final String ACCOUNTS = "accounts";
    public static final String CONTRAGENT = "contragent";

    @Comment("Признак одиночного платежа ")
    @Column(name = "ALONEPAYMENT")
    int alonePayment = 0;

    @Comment("Статус проверки")
    @Column(name = "CHECKSTATUS")
    String checkStatus;

    @Comment("Класс описателя документа")
    @Column
    String type;

    @Comment("Тип платежного документа")
    @Column(name = "PAYMENTTYPE")
    String paymentType;

//    @Comment("Идентификатор документа во внешней системе")
//    @Column(length = Dictionary.TEXT64)
//    String externalId;

    @Comment("Номер платежного документа")
    @Column(length = FieldSize.DOC_NUMBER, name = "DOCNUMBER")
    String docNumber;

    @Comment("Дата создания документа")
    @Column(name = "DOCDATE")
    Date docDate;

//    @Comment("Дата последней модификации документа")
//    @Column
//    Date lastModifyDate;

    @Comment("Дата валютирования")
    @Column(name = "VALUEDATE")
    Date valueDate;

//    @Comment("Время принятия электронного документа в АБС банка")
//    @Column
////    @NotAudited
//    Date absAcceptDate;

//    @Comment("Срочность")
//    @Column
//    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean urgent;

    @Comment("ID организации (плательщика)")
    @Column(length = Const.TEXT36, name =  "ORGID")
    @DoNotSerialize
    String orgId;

    @Comment("ID подразделения (плательщика)")
    @Column(length = Const.TEXT36, name = "BRANCHID")
    @DoNotSerialize
    String branchId;

    @Comment("ID счета организации (плательщика)")
    @Column(length = Const.TEXT36, name = "ACCOUNTID")
//    @DoNotSerialize
//    @NotAudited
    String accountId;

    @Comment("Статус документа")
    @ManyToOne(fetch = FetchType.LAZY)
    @Fetch(FetchMode.JOIN)
//    @NotAudited
    StateMachine state;

//    @Comment("Статус документа")
//    @NotAudited
//    StateInfo stateInfo = new StateInfo();

//    @Comment("Метка - является ли объект шаблоном")
//    @Column
//    @DoNotSerialize
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    @NotAudited
//    Boolean template;

//    @Comment("Ссылка на коллекцию подписей")
//    @ManyToOne(optional = true, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    @JoinColumn(name = "signCollectionId")
//    SignCollection signCollection;

    /* Пенсионный, налоговый и социальный платежи */

//    @Comment("Сотрудники")
//    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "parentPayment")
//    @BatchSize(size = Dictionary.BATCH_SIZE)
////    @NotAudited
//    Set<PaymentEmployee> employeePayments = new LinkedHashSet<>();

    /* Пенсионный платеж */

//    @Comment("Тип отчисления")
//    @Column(length = FieldSize.DEDUCTION_TYPE)
////    @NotAudited
//    String deductionType;

    /* Платеж в бюджет */

//    @Comment("Список налоговых платежей")
//    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "parentPayment")
//    @BatchSize(size = Dictionary.BATCH_SIZE)
////    @NotAudited
//    Set<PaymentTax> taxCommitteePayments = new LinkedHashSet<>();

    /* Социальный платеж */

//    @Comment("Период")
//    @NotAudited
//    @Column
//    Date period;

    /* Плательщик */

    @Comment("БИН плательщика")
    @Column(length = FieldSize.ORG_INN, name = "PAYERINN")
    String payerInn;

    @Comment("Счет плательщика")
    @Column(length = FieldSize.ACCOUNT_NUMBER, name = "PAYERACCOUNT")
    String payerAccount;

    @Comment("Наименование плательщика")
    @Column(length = FieldSize.ORG_NAME, name = "PAYERNAME")
    String payerName;

    @Comment("Код отправителя денег")
    @Column(length = FieldSize.ORGTYPEKZ_CODE, name = "PAYERORGTYPE")
    String payerOrgType;

    @Comment("Наименование банка плательщика")
    @Column(name = "PAYERBANKNAME")
    String payerBankName;

    @Comment("БИК банка плательщика")
    @Column(length = FieldSize.BANK_BIC, name = "PAYERBANKBIC")
    String payerBankBic;

    @Comment("Сумма платежа")
    @Column(precision = FieldSize.AMOUNT_PRECISION, scale = FieldSize.AMOUNT_SCALE)
    BigDecimal amount;

//    @Comment("Рассчитать НДС")
//    @Column
//    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean calculateNds;

    @Comment("НДС")
    @Column(precision = FieldSize.AMOUNT_PRECISION, scale = FieldSize.AMOUNT_SCALE)
    BigDecimal nds;

    @Comment("БИК банка получателя")
//    @Column(length = FieldSize.BANK_BIC)
    @Column(name = "BENEFBANKBIC")
//    @NotAudited
    String benefBankBic;

    @Comment("Наименование банка получателя")
    @Column(name = "BENEFBANKNAME")
//    @NotAudited
    String benefBankName;

    @Column(name = "CURRENTSTATENAMESYS")
    String currentstatenamesys;

    @Comment("Счет получателя")
    @Column(length = FieldSize.ACCOUNT_NUMBER, name = "BENEFACCOUNT")
//    @NotAudited
    String benefAccount;

    @Comment("БИН получателя")
    @Column(length = FieldSize.ORG_INN, name = "BENEFINN")
//    @NotAudited
    String benefInn;

    @Comment("Наименование получателя")
    @Column(length = FieldSize.ORG_NAME, name = "BENEFNAME")
//    @NotAudited
    String benefName;

    @Comment("Код бенефициара")
    @Column(length = FieldSize.ORGTYPEKZ_CODE, name = "BENEFORGTYPE")
//    @NotAudited
    String benefOrgType;

    /* Детали платежа */

    @Comment("Код бюджетной классификации")
//    @Column(length = FieldSize.BUDGET_CODE, name = "BUDGETCODE")
    @Column(name = "BUDGETCODE")
//    @NotAudited
    String budgetCode;

//    @Comment("VIN-код не предусмотрен")
//    @Column
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean vinChk;

//    @Comment("VIN-код")
//    @Column(length = FieldSize.VIN_CODE)
////    @NotAudited
//    String vinCode;

    @Comment("Код назначения платежа")
    @Column(length = FieldSize.PAY_PURPOSE_CODE, name = "PAYPURPOSECODE")
    String payPurposeCode;

    @Comment("Назначение платежа")
    @Column(length = FieldSize.LONG_TEXT, name = "PAYMENTPURPOSE")
//    @Lob
//    @DoNotSerialize
    String paymentPurpose;

    @Comment("Учетный номер контракта/ID контракта")
    @Column(length = 18, name="CONTRACTNUM")
//    @NotAudited
    String contractNum;

//    @Comment("Рег.свидетельство/свидетельство об уведомлении")
//    @Column(length = Dictionary.TEXT12)
//    @NotAudited
//    String registration;

//    @Comment("Флаг активен, если организация под которой создается документ, является резидентом")
//    @Column
//    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean paymentAcceptResident;

    /* Подписанты */

//    @Comment("Руководитель")
//    @Column
//    @NotAudited
//    String executive;

//    @Comment("Руководитель ID")
//    @Column(length = FieldSize.UUID)
//    @NotAudited
//    String executiveId;

//    @Comment("Главный бухгалтер")
//    @Column
//    @NotAudited
//    String chiefAccountant;

//    @Comment("Главный бухгалтер ID")
//    @Column(length = FieldSize.UUID)
//    @NotAudited
//    String chiefAccountantId;

    /* Информация из банка */

//    @Comment("Дата поступления в банк плательщика")
//    @Column
//    @NotAudited
//    Date bankAcceptDate;

//    @Comment("Дата списания со счета плательщика")
//    @Column
//    @NotAudited
//    Date operationDate;

//    @Comment("Отметки банка плательщика")
//    @Column(length = FieldSize.MSG_FROM_BANK)
//    @Lob
//    @NotAudited
//    Boolean msgFromBank;

//    @Comment("Ответственный исполнитель банка плательщика")
//    @Column(length = FieldSize.AUTHOR)
//    @NotAudited
//    String bankMessageAuthor;

//    @Comment("Платеж осуществляется за физ. лицо")
//    @Column
//    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean forIndividual;

    /**
     * При миграции документов Платеж в бюджет с версии 2.0.7 на 2.2.0 значения полей переносятся следующим образом:
     * benefInn -> legacyBenefInn
     * benefName -> legacyBenefName
     * taxCommitteeBin -> benefInn
     * taxCommitteeName -> benefName
     * Поля legacyBenefInn и legacyBenefName используются в дайджесте и необходимы для поддержки подписей мигрированных документов.
     */
//    @Comment("БИН получателя до версии 2.2.0")
//    @Column(length = FieldSize.ORG_INN)
//    @NotAudited
//    String legacyBenefInn;

//    @Comment("Наименование получателя до версии 2.2.0")
//    @Column(length = FieldSize.ORG_NAME)
////    @NotAudited
//    String legacyBenefName;

//    @Comment("Коммисия")
//    @Column(precision = FieldSize.AMOUNT_PRECISION, scale = FieldSize.AMOUNT_SCALE)
////    @NotAudited
//    BigDecimal commission;

//    @Comment("Признак Создан в мобильном приложение")
//    @Column
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean createdInMobileApp;

//    @Comment("Оповестить по SMS")
//    @Column
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean notifyBySMS;

//    @Comment("Оповестить по E-mail")
//    @Column
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean notifyByEMail;

//    @Comment("ID получателей оповещений ")
//    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    @JoinColumn(name = "ReviewersNotificationId")
//    @DoNotSerialize
////    @NotAudited
//    ReviewersNotification infoPayId;

    @Comment("Номер контракта")
    @Column(name = "CONTRACTNUMBER")
//    @NotAudited
    String contractNumber;

    @Comment("Дата контракта")
    @Column(name = "CONTRACTDATE")
//    @NotAudited
    Date contractDate;

//    @Comment("Код валютной операции для мониторинга валютных операций")
//    @Column(length = Dictionary.TEXT5)
////    @NotAudited
//    String codVoKz;

//    @Comment("Описание кода валютной операции")
//    @Column(length = Dictionary.TEXT4000)
////    @NotAudited
//    String codVoKzDesc;

//    @Comment("Код признака платежа для мониторинга валютных операций")
//    @Column(length = Dictionary.TEXT1)
////    @NotAudited
//    String signOfPayment;

//    @Comment("Описание признака платежа для мониторинга валютных операций")
////    @NotAudited
//    String signOfPaymentDesc;

    @Comment("Дата получения учетного номера контракта")
    @Column(name = "CONTRACTNUMDATE")
//    @NotAudited
    Date contractNumDate;

    @Comment("Дата получения регистрационного свидетельства/свидетельства об уведомлении")
    @Column(name = "REGISTRATIONDATE")
//    @NotAudited
    Date registrationDate;

//    @Comment("Комментарии")
////    @NotAudited
//    String contractDesc;

//    @Comment("Код сектора экономики отправителя денег по валютному контракту")
//    @Column(length = Dictionary.TEXT1)
////    @NotAudited
//    String contractSenderSectorCode;

//    @Comment("Признак резидентства отправителя денег по валютному контракту")
//    @Column(length = Dictionary.TEXT1)
////    @NotAudited
//    String contractSenderResidenceCode;

//    @Comment("Код страны резиденства")
//    @Column(length = Dictionary.TEXT2)
////    @NotAudited
//    String contractSenderCountryCode;

//    @Comment("ФИО физ.лица или наименование юр.лица отправителя денег по валютному контракту")
//    @Column
////    @NotAudited
//    String contractSenderName;

//    @Comment("ИИН/БИН отправителя денег по валютному контракту")
//    @Column(length = FieldSize.ORG_INN)
////    @NotAudited
//    String contractSenderBin;

//    @Comment("Код сектора экономики получателя денег по валютному контракту")
//    @Column(length = Dictionary.TEXT1)
////    @NotAudited
//    String contractRecepientSectorCode;

//    @Comment("Признак резидентства получателя денег по валютному контракту")
//    @Column(length = Dictionary.TEXT1)
////    @NotAudited
//    String contractRecepientResidenceCode;

//    @Comment("Код страны резиденства")
//    @Column(length = Dictionary.TEXT2)
////    @NotAudited
//    String contractRecepientCountryCode;

//    @Comment("ФИО физ.лица или наименование юр.лица получателя денег по валютному контракту")
////    @NotAudited
//    String contractRecepientName;

//    @Comment("ИИН/БИН получателя денег по валютному контракту")
//    @Column(length = FieldSize.ORG_INN)
////    @NotAudited
//    String contractRecepientBin;

//    @Comment("Тип платежа (бюджет / контрагент / счета)")
//    @Column
//    @Enumerated(EnumType.STRING)
////    @NotAudited
//    PaymentType paymentOrderType;

//    @Comment("Системный флаг, что сущность проиндексирована в ElasticSearch")
//    @Column
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean indexed;

//    @Comment("Признак платежа себе")
//    @Column(length = FieldSize.ORG_INN)
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean toMyself;

//    @Comment("Признак документа 'К акцепту'")
//    @Column
////    @NotAudited
//    @Convert(converter = org.hibernate.type.NumericBooleanConverter.class)
//    Boolean forAccept;

}
