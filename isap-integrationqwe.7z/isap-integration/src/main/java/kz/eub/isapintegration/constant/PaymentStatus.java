package kz.eub.isapintegration.constant;



public enum PaymentStatus {
    AWAITING_APPROVAL("2000", "Ожидает санкции"), //expectSanction
    UNDER_REVIEW("2021", "На санкционировании"), //inSanction
    APPROVED("2001", "Санкционирован"), //sanctioned
    APPROVAL_DENIED("2011", "Отказ санкционирования"); //rejectedSanction

    private final String code;
    private final String description;

    PaymentStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return String.format("%s (%s)", code, description);
    }

    public static PaymentStatus fromCode(String code) {
        for (PaymentStatus status : PaymentStatus.values()) {
            if (status.code.equals(code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown status code: " + code);
    }
}