package kz.eub.isapintegration.service;

import jakarta.transaction.Transactional;
import kz.eub.isapintegration.constant.PaymentStatus;
import kz.eub.isapintegration.exceptionHandler.PaymentNotFoundException;
import kz.eub.isapintegration.model.dto.response.GetPaymentsListResponse;
import kz.eub.isapintegration.model.dto.response.PaymentDto;
import kz.eub.isapintegration.model.entity.Payment;
import kz.eub.isapintegration.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    private PaymentDto mapToPaymentDto(Payment payment) {
        PaymentDto dto = new PaymentDto();
        dto.setId(payment.getId());
        dto.setAccountId(payment.getAccountId());
        dto.setPaymentType(payment.getPaymentType());
        dto.setSysCreateTime(payment.getSysCreateTime());
        dto.setValueDate(payment.getValueDate());
        dto.setDocNumber(payment.getDocNumber());
        dto.setAmount(payment.getAmount());
        dto.setPayerName(payment.getPayerName());
        dto.setPayerInn(payment.getPayerInn());
        dto.setPayerAccount(payment.getPayerAccount());
        dto.setPayPurposeCode(payment.getPayPurposeCode());
        return dto;
    }

    public GetPaymentsListResponse getPaymentList() {
        List<Payment> payments = paymentRepository.findByCheckStatus(PaymentStatus.AWAITING_APPROVAL.getCode());

        if (payments.isEmpty()) {
            throw new PaymentNotFoundException("Payment not found for status: " + PaymentStatus.AWAITING_APPROVAL.getDescription());
        }

        GetPaymentsListResponse response = new GetPaymentsListResponse();
        response.getPayments().addAll(payments.stream().map(this::mapToPaymentDto).toList());

        String statusState = "REJECT_SANCTION";

        try {
            sendMessageToQueue(payments, statusState);
            updatePaymentStatus(PaymentStatus.AWAITING_APPROVAL.getCode(), PaymentStatus.UNDER_REVIEW.getCode());
        } catch (Exception e) {
            log.error("Failed to process payment update: {}", e.getMessage());
            throw new PaymentProcessingException("Failed to update payment status", e);
        }

        return response;
    }

    @Transactional
    public void updatePaymentStatus(String oldStatus, String newStatus) {
        paymentRepository.updateStatus(oldStatus, newStatus);
    }


    public Payment getPaymentsByIdAndStatus(String id, String status) {
        return paymentRepository.findByIdAndCheckStatus(id, status);
    }
    @Transactional
    public void updatePaymentStatusId(String paymentId, String newStatus) {
        paymentRepository.findByIdAndUpdateCheckStatus(paymentId, newStatus);
    }

    @Autowired
    private JmsTemplate jmsTemplate;

//    public void sendMessageToQueue(String docId, String statusState) {
//        LocalDateTime dateTime = LocalDateTime.now();
//        String message = "<?xml version=\"1.1\" encoding=\"UTF-8\"?>\n" +
//                "<StateResponse xmlns:i=\"http://bssys.com/sbns/integration\"\n" +
//                "               xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
//                "               xsi:schemaLocation=\"http://bssys.com/sbns/integration schema.xsd\">\n" +
//                "       <createTime>$dateTime</createTime>\n" +
//                "       <docType>KzPayment</docType>\n" +
//                "       <docId>$docId</docId>\n" +
//                "       <state>$statusState</state>\n" +
//                "       <bankMessage/>\n" +
//                "       <messageOnlyForBank/>\n" +
//                "    </StateResponse>";
//
//        jmsTemplate.convertAndSend("CC_Output", message);
//    }

    public void sendMessageToQueue(List<Payment> payments, String statusState) {
        LocalDateTime dateTime = LocalDateTime.now();

        for (Payment payment : payments) {
            String docId = payment.getId().toString(); // Предполагается, что у Payment есть метод getId(), возвращающий идентификатор документа
            String message = String.format(
                    "<?xml version=\"1.1\" encoding=\"UTF-8\"?>\n" +
                            "<StateResponse xmlns:i=\"http://bssys.com/sbns/integration\"\n" +
                            "               xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                            "               xsi:schemaLocation=\"http://bssys.com/sbns/integration schema.xsd\">\n" +
                            "       <createTime>%s</createTime>\n" +
                            "       <docType>KzPayment</docType>\n" +
                            "       <docId>%s</docId>\n" +
                            "       <state>%s</state>\n" +
                            "       <bankMessage/>\n" +
                            "       <messageOnlyForBank/>\n" +
                            "    </StateResponse>", dateTime, docId, statusState);

            jmsTemplate.convertAndSend("CC_Output", message);
        }
    }


}