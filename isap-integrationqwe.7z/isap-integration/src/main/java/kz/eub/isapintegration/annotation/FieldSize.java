package kz.eub.isapintegration.annotation;


/**
 * Утилитарный класс с размерами полей для Казахстана
 *
 * @author Andrey Gorchakov
 */
public final class FieldSize {

    // Реквизиты организаций
    public static final int ORGTYPEKZ_CODE        = 2;
    public static final int ORGTYPEKZ_DESCRIPTION = 255;
    public static final int ORGTYPEKZ_ECONSECTOR  = 1;
    public static final int ORG_INN               = 12;
    public static final int ORG_NAME              = 355;
    public static final int ORG_OFFICIALS         = 255;
    public static final int ORG_KPP               = 9;

    // Счета / Банки
    public static final int ACCOUNT_NUMBER     = 20;
    public static final int INT_ACCOUNT_NUMBER = 34;
    public static final int BANK_NAME          = 255;
    public static final int BANK_BIC           = 11;
    public static final int BANK_SWIFT         = 20;
    public static final int BANK_CODE          = 3;
    public static final int CARD_NUMBER        = 16;

    // Справочные поля
    public static final int PAY_PURPOSE_CODE   = 3; //КНП
    public static final int PAY_PURPOSE_DESC   = 4000;
    public static final int BUDGET_CODE        = 6; //КБК
    public static final int BUDGET_CODE_DESC   = 1000;
    public static final int CURRENCY_CODE      = 3;
    public static final int CURRENCY_ISO_CODE  = 3;
    public static final int CURRENCY_TYPE      = 1;
    public static final int COUNTRY_CODE_02    = 2;
    public static final int COUNTRY_CODE_03    = 3;
    public static final int VO_CODE            = 5;
    public static final int VO_CODE_DESC       = 4000;
    public static final int VIN_CODE           = 20;
    public static final int VIN_CODE_MIN       = 1;
    public static final int INDEX_PAY_BASE       = 2;
    public static final int INDEX_OF_PAYMENT     = 3;
    public static final int INDEX_TAX_PAYER      = 3;
    public static final int TAX_COMMITTEE_CODE = 4; //Код налогового коммитета
    public static final int IIN                = 12; //ИИН
    public static final int KBE                = 2; //Код бенефициара (КБе)
    public static final int CONVERSION_TARGET_CODE = 6;


    // Точность для денежных полей
    public static final int AMOUNT_PRECISION = 18;
    public static final int AMOUNT_SCALE     = 2;
    public static final int CURRENCY_RATE_PRECISION     = 10;
    public static final int CURRENCY_RATE_SCALE     = 4;
    public static final int COMMISSION_AMOUNT_PRECISION     = 20;

    // Общие
    public static final int UUID         = 36;
    public static final int DEFAULT_TEXT = 255;
    public static final int LONG_TEXT    = 4000;
    public static final int FILE_NAME    = 150;

    public static final int DOC_NUMBER      = 64;
    public static final int PAYMENT_PURPOSE = 4000; // Назначение платежа
    public static final int ECNP_250 = 250;
    public static final int PAYMENT_PURPOSE_BUDGETARY_PAYMENT = 482;
    public static final int MSG_FROM_BANK   = 4000;
    public static final int ADDRESS         = 255;
    public static final int COMMISSION_TYPE = 30;
    public static final int AUTHOR          = 64;
    public static final int CONTRACT_NUMBER = 64;

    public static final int FIX_SUM  = 15;
    public static final int PRIORITY = 3;

    // Пенсионный платеж
    public static final int DEDUCTION_TYPE = 1; // Тип отчисления
    public static final int DEDUCTION_TYPE_DESC = 300;
    public static final int DEDUCTION_TYPE_DOCTYPE = 14;

    //Точность для курса исполнения
    public static final int COURSE_PRECISION = 20;
    public static final int COURSE_SCALE = 4;

    public static final int TEXT10 = 10;

    private FieldSize(){}
}

