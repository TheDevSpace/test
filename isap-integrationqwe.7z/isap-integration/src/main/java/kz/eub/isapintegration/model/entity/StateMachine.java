package kz.eub.isapintegration.model.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.Index;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Comment("Экземпляры машин состояний (ЖЦ)")
@Entity
@Table(
        name = "SBNS_SM_INSTANCE"
)
@Inheritance(
        strategy = InheritanceType.SINGLE_TABLE
)
@DiscriminatorColumn(
        columnDefinition = "varchar(31) default 'StateMachine'"
)
public class StateMachine extends BaseEntity {
    private static final long serialVersionUID = 9074110272898493957L;
    private static final int TEXT256 = 256;
    private static final int TEXT4000 = 4000;
//    @Comment("История изменения состояний")
//    @OneToMany(
//            fetch = FetchType.LAZY,
//            cascade = {CascadeType.ALL},
//            orphanRemoval = true,
//            mappedBy = "stateMachine"
//    )
//    @OrderBy("enterDate")
//    private List<StateHistory> stateHistory;
    @Comment("Идентификатор класса машины состояний")
    @Column(
            name = "statemachineclassid"
    )
    @Index(
            name = "<auto_generated_name>"
    )
    private String stateMachineClassId;
    @Comment("Системное наименование текущего статуса")
    @Column(
            name = "currentstatenamesys"
    )
    private String currentStateNameSys;
//    @Comment("Коллекция параметров экземпляра машины состояний")
//    @ElementCollection(
//            fetch = FetchType.LAZY
//    )
//    @CollectionTable(
//            name = "SBNS_SM_PARAMS"
//    )
//    @MapKeyColumn(
//            name = "PARAM_NAME"
//    )
//    @Column(
//            name = "PARAM_VALUE",
//            length = 4000
//    )
//    @DoNotPrint
//    private Map<String, String> params = new HashMap();
//    @DoNotPrint
//    private transient Boolean changingState = false;

    public StateMachine() {
    }

//    public Boolean getChangingState() {
//        return this.changingState;
//    }

//    public void setChangingState(Boolean changingState) {
//        this.changingState = changingState;
//    }

//    public List<StateHistory> getStateHistory() {
//        return this.stateHistory;
//    }

//    public void setStateHistory(List<StateHistory> stateHistory) {
//        this.stateHistory = stateHistory;
//    }

    public String getStateMachineClassId() {
        return this.stateMachineClassId;
    }

    public void setStateMachineClassId(String stateMachineClassId) {
        this.stateMachineClassId = stateMachineClassId;
    }

    public String getCurrentStateNameSys() {
        return this.currentStateNameSys;
    }

    public void setCurrentStateNameSys(String currentStateNameSys) {
        this.currentStateNameSys = currentStateNameSys;
    }

//    public Map<String, String> getParams() {
//        return this.params;
//    }
}
