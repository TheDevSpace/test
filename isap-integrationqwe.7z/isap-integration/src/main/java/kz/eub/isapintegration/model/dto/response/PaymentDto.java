package kz.eub.isapintegration.model.dto.response;

import jakarta.xml.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Date;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "id",
        "accountId",
        "paymentType",
        "sysCreateTime",
        "valueDate",
        "docNumber",
        "amount",
        "payerName",
        "payerInn",
        "payerAccount",
        "payPurposeCode"
})
@XmlRootElement(name = "paymentDto")
public class PaymentDto {

    @XmlElement(name = "id", required = true)
    private String id;

    @XmlElement(name = "accountid", required = true)
    private String accountId;

    @XmlElement(name = "paymenttype", required = true)
    private String paymentType;

    @XmlElement(name = "sysCreateTime", required = true)
    private Date sysCreateTime;

    @XmlElement(name = "valuedate", required = true)
    private Date valueDate;

    @XmlElement(name = "docnumber", required = true)
    private String docNumber;

    @XmlElement(name = "amount", required = true)
    private BigDecimal amount;

    @XmlElement(name = "payerName", required = true)
    private String payerName;

    @XmlElement(name = "payerinn", required = true)
    private String payerInn;

    @XmlElement(name = "payeraccount", required = true)
    private String payerAccount;

    @XmlElement(name = "paypurposecode", required = true)
    private String payPurposeCode;

    // Геттеры и сеттеры
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public Date getSysCreateTime() {
        return sysCreateTime;
    }

    public void setSysCreateTime(Date sysCreateTime) {
        this.sysCreateTime = sysCreateTime;
    }

    public Date getValueDate() {
        return valueDate;
    }

    public void setValueDate(Date valueDate) {
        this.valueDate = valueDate;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPayerName() {
        return payerName;
    }

    public void setPayerName(String payerName) {
        this.payerName = payerName;
    }

    public String getPayerInn() {
        return payerInn;
    }

    public void setPayerInn(String payerInn) {
        this.payerInn = payerInn;
    }

    public String getPayerAccount() {
        return payerAccount;
    }

    public void setPayerAccount(String payerAccount) {
        this.payerAccount = payerAccount;
    }

    public String getPayPurposeCode() {
        return payPurposeCode;
    }

    public void setPayPurposeCode(String payPurposeCode) {
        this.payPurposeCode = payPurposeCode;
    }
}