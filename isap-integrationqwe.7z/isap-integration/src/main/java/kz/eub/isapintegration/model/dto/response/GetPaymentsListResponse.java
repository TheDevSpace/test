package kz.eub.isapintegration.model.dto.response;

import jakarta.xml.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "payments"
})
@XmlRootElement(namespace="http://localhost:8080/ws/payments", name = "getPaymentsListResponse")
public class GetPaymentsListResponse {


    @XmlElement(name = "payments", namespace="http://localhost:8080/ws/payments",  required = true)
    protected List<PaymentDto> payments = new ArrayList<>();


    public void addPayment(PaymentDto payment) {
        this.payments.add(payment);
    }


    public List<PaymentDto> getPayments() {
        return payments;
    }


    public void setPayments(List<PaymentDto> payments) {
        this.payments = payments;
    }
}

