package kz.eub.isapintegration.model.dto.response;

import jakarta.xml.bind.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "result",
})
@XmlRootElement(namespace="http://localhost:8080/ws/payments", name="PostNewStatusResponse")
public class PostNewStatusResponse {

    @XmlElement(namespace = "http://localhost:8080/ws/payments", required = true)
    protected String result;
}