package kz.eub.reportretrievalservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import kz.eub.reportretrievalservice.service.AbisReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RequiredArgsConstructor
@Slf4j
@RestController
@RequestMapping("/api/v1/")
public class AbisReportController {
    private final AbisReportService abisReportService;

    @Operation(tags = "Запрос для приема данных от рисков для получения отчета")
    @GetMapping(path = "/report/abis", produces = "application/json;charset=utf8")
    public ResponseEntity<String> getReportAbis(@RequestParam String bin,
                                                String reportType) {
        log.info("Start request for receiving risk data to obtain a report");
        if (bin.length() != 12) {
            return new ResponseEntity<>("Error: The length of the bin is not 12", HttpStatus.BAD_REQUEST);
        }
        try {
            ResponseEntity<String> resp = abisReportService.getAbisData(bin, reportType);
            return new ResponseEntity<>(resp.getBody(), resp.getStatusCode());
        } catch (Exception e) {
            return new ResponseEntity<>("Не успешно: данные не доставлены", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
