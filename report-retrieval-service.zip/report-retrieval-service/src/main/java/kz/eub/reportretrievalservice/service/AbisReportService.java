package kz.eub.reportretrievalservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kz.eub.reportretrievalservice.domain.Abis.*;
import kz.eub.reportretrievalservice.domain.SoHo.Auth.AccessTokenResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.net.URI;


@Service
@RequiredArgsConstructor
public class AbisReportService {
    private final AuthAbisService authAbisService;

    @Value("${api.abis.url}")
    private String apiUrl;
    @Value("${api.abis.path.type}")
    private String apiUrlPath;
//    @Value("${api.abis.callback.url}")
    private String callbackUrl;
    @Value("${api.abis.path.register}")
    private String apiUrlRegister;

    private static int counter = 0;
//    private final CallbackReportRepository callbackReportRepository;

    public static synchronized int generateRequestId() {
        counter++;
        if (counter == Integer.MAX_VALUE) {
            counter = 1;
        }
        return counter;
    }

    public ResponseEntity<String> getAbisData(String bin, String reportType) {
        try {
            //1. login
            ResponseEntity<String> authResponse = authAbisService.authenticate();
            AccessTokenResponse accessTokenResponse = parseAuthBody(authResponse);
            String apiToken = accessTokenResponse.getAccess().getHash();

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + apiToken);
            headers.setContentType(MediaType.APPLICATION_JSON);

            //2. v1/report/type
            RequestEntity<Void> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, URI.create(apiUrl+apiUrlPath));
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> responseEntity = restTemplate.exchange(requestEntity, String.class);
            if (responseEntity.getStatusCode() == HttpStatus.UNAUTHORIZED || responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST) {
                return ResponseEntity.status(responseEntity.getStatusCode()).body(responseEntity.getBody());
            }

            ObjectMapper objectMapper = new ObjectMapper();
            ReportTypeResponse reportTypeResponse = objectMapper.readValue(responseEntity.getBody(), ReportTypeResponse.class);
            ReportRequest reportRequest = new ReportRequest();

            ReportData2 reportData2 = new ReportData2();
            if (reportType.toUpperCase().contains("PRO")) {
                reportData2 = reportTypeResponse.getData().get(1);
            } else {
                reportData2 = reportTypeResponse.getData().get(0);
            }
            reportRequest.setProduct_code(reportData2.getCode());
            int date = generateRequestId();
            reportRequest.setRequest_id(date);
            reportRequest.setBin(bin);
            reportRequest.setCallback_url(callbackUrl);
            reportRequest.setClient_bin("950240000112");

            //3. v1/report/register
            ResponseEntity<String> response = registerReport(reportRequest, apiToken);
            if (response.getStatusCode() == HttpStatus.NOT_FOUND || response.getStatusCode() == HttpStatus.BAD_REQUEST) {
                return ResponseEntity.status(response.getStatusCode()).body(response.getBody());
            }
            ReportResponse reportResponse = parseAuthBody2(response);


            //5. v1/report/get

            try {
                Thread.sleep(25000); // Задержка на 1 минуту
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }

            ResponseEntity<String> totalResp = getReport2(reportResponse.getData().getReport_id(), reportResponse.getFcb_request_id(), apiToken);
            if (totalResp.getStatusCode() == HttpStatus.NOT_FOUND || totalResp.getStatusCode() == HttpStatus.BAD_REQUEST) {
                return ResponseEntity.status(totalResp.getStatusCode()).body(totalResp.getBody());
            }

            return ResponseEntity.ok(totalResp.getBody());
        } catch (HttpClientErrorException e) {
            String responseBody = e.getResponseBodyAsString();
            return ResponseEntity.status(e.getStatusCode()).body(responseBody);
        } catch (Exception e) {
            // Обработка других исключений
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Внутренняя ошибка сервера");
        }
    }

    public AccessTokenResponse parseAuthBody(ResponseEntity<String> response) throws JsonProcessingException {
        String jsonBody = response.getBody();
        ObjectMapper objectMapper = new ObjectMapper();
        AccessTokenResponse accessTokenResponse = objectMapper.readValue(jsonBody, AccessTokenResponse.class);
        return accessTokenResponse;
    }

    public ReportResponse parseAuthBody2(ResponseEntity<String> response) throws JsonProcessingException {
        String jsonBody = response.getBody();
        ObjectMapper objectMapper = new ObjectMapper();
        ReportResponse reportResponse = objectMapper.readValue(jsonBody, ReportResponse.class);
        return reportResponse;
    }

    public ResponseEntity<String> registerReport(ReportRequest reportRequest, String apiToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + apiToken);
        headers.set("Client-type", "B2B");
        HttpEntity<ReportRequest> requestEntity = new HttpEntity<>(reportRequest, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(apiUrl + apiUrlRegister, requestEntity, String.class);
        return responseEntity;
    }

    public ResponseEntity<String> getReport2(int reportId, String fcbRequestId, String apiToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + apiToken);
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        String url = UriComponentsBuilder.fromHttpUrl(apiUrl)
                .path("/v1/report/get/{reportId}")
                .queryParam("fcb_request_id", fcbRequestId)
                .buildAndExpand(reportId)
                .toUriString();

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
        return responseEntity;
    }

}