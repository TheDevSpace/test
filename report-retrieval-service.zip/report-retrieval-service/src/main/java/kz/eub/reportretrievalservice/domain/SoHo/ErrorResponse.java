package kz.eub.reportretrievalservice.domain.SoHo;

import lombok.Data;

@Data
public class ErrorResponse {
    private int result;
    private String resultDescr;

    // Геттеры и сеттеры
}
