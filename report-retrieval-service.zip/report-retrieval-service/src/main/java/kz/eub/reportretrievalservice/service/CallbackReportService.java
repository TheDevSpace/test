package kz.eub.reportretrievalservice.service;


import kz.eub.reportretrievalservice.domain.Abis.CallbackResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class CallbackReportService {

//    private final CallbackReportRepository callbackReportRepository;
    public ResponseEntity<String> handleCallback(String productCode, String bin, int reportId, String status) {
        CallbackResponse callbackResponse = new CallbackResponse();
        callbackResponse.setBin(bin);
        callbackResponse.setReportId(reportId);
        callbackResponse.setStatus(status);
        callbackResponse.setProductCode(productCode);
//        callbackReportRepository.save(callbackResponse);
        return ResponseEntity.ok("Callback processed successfully");
    }
}
