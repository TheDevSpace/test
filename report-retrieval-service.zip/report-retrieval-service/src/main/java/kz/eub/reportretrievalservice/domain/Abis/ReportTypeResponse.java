package kz.eub.reportretrievalservice.domain.Abis;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class ReportTypeResponse {
    private String status;
    private String message;
    private List<ReportData2> data;
//    private Date dates;
}
