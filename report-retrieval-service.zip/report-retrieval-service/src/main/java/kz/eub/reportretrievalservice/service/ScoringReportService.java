package kz.eub.reportretrievalservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kz.eub.reportretrievalservice.domain.SoHo.Auth.AccessTokenResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@RequiredArgsConstructor
public class ScoringReportService {

    private final AuthSoHoService authSoHoService;
    @Value("${api.soho.url}")
    private String apiUrl;
    @Value("${api.soho.path.scoring}")
    private String apiUrlPath;
    private static String IIN_BIN = "IIN_BIN";

    public ResponseEntity<String> getScoringData(String bin) {
        try {
            ResponseEntity<String> authResponse = authSoHoService.authenticate();
            AccessTokenResponse accessTokenResponse = parseAuthBody(authResponse);
            String apiToken = accessTokenResponse.getAccess().getHash();

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + apiToken);
            headers.setContentType(MediaType.APPLICATION_JSON);

            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(apiUrl)
                    .path(apiUrlPath)
                    .queryParam(IIN_BIN, bin);
            System.out.println("test121: " + builder);;

            RequestEntity<Void> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, builder.build().toUri());

            System.out.println("test122: " + requestEntity);

            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> responseEntity = restTemplate.exchange(requestEntity, String.class);

            System.out.println("test123: " + responseEntity);

            return ResponseEntity.ok(responseEntity.getBody());
        } catch (HttpStatusCodeException e) {
            // Обработка ошибок HTTP
//            HttpStatus statusCode = e.getStatusCode();
            String responseBody = e.getResponseBodyAsString();

            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Субъект не найден в БДКИ: " + responseBody);
            } else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Ошибка при расчете значения скоринга: " + responseBody);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseBody);
            }
        } catch (Exception e) {
            // Обработка исключений, если они возникнут
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Внутренняя ошибка сервера");
        }
    }


    public AccessTokenResponse parseAuthBody(ResponseEntity<String> response) throws JsonProcessingException {
        String jsonBody = response.getBody();
        ObjectMapper objectMapper = new ObjectMapper();
        AccessTokenResponse accessTokenResponse = objectMapper.readValue(jsonBody, AccessTokenResponse.class);

        return accessTokenResponse;
    }
}
