//package kz.eub.reportretrievalservice.repository;
//
//
//import kz.eub.reportretrievalservice.domain.Abis.CallbackResponse;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface CallbackReportRepository extends JpaRepository<CallbackResponse, Long> {
//    CallbackResponse findAllByReportId(int reprtId);
//}