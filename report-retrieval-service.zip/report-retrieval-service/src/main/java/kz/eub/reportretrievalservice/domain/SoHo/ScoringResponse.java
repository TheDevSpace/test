package kz.eub.reportretrievalservice.domain.SoHo;

import lombok.Data;

@Data
public class ScoringResponse {
    private int result;
    private String resultDescr;
    private ScoringData data;

    // Геттеры и сеттеры
}