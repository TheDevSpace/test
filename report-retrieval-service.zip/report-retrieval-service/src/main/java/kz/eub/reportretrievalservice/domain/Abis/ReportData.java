package kz.eub.reportretrievalservice.domain.Abis;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class ReportData {
    private int report_id;

    // геттеры и сеттеры
}