package kz.eub.reportretrievalservice.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;

@Service
@RequiredArgsConstructor
public class AuthAbisService {

    @Value("${api.abis.url}")
    private String authUrl;

    @Value("${api.abis.path.login}")
    private String authLogin;

    @Value("${api.abis.path.refresh}")
    private String authRefresh;

    @Value("${api.username}")
    private String username;

    @Value("${api.password}")
    private String password;


    public ResponseEntity<String> authenticate() {
        // Кодирование логина и пароля в формат BASE64
        String credentials = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());

        // Создание заголовка Authorization
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Basic " + credentials);
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Создание запроса с заголовком
        HttpEntity<String> request = new HttpEntity<>(headers);

        // Выполнение POST-запроса для аутентификации
        ResponseEntity<String> response = new RestTemplate().exchange(authUrl+authLogin, HttpMethod.POST, request, String.class);

        return response;
    }


    public ResponseEntity<String> refreshTokens(String refreshToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Создание тела запроса с refresh token
        String requestBody = "{\"token_hash\": \"" + refreshToken + "\"}";

        // Создание запроса с заголовками и телом
        HttpEntity<String> request = new HttpEntity<>(requestBody, headers);

        // Выполнение POST-запроса для обновления токенов
        ResponseEntity<String> response = new RestTemplate().postForEntity(authUrl+authRefresh, request, String.class);

        return response;
    }

}
