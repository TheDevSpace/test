package kz.eub.reportretrievalservice.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;


@Service
@RequiredArgsConstructor
public class AuthSoHoService {

    @Value("${api.soho.url}")
    private String apiUrl;

    @Value("${api.soho.path.auth}")
    private String authUrl;

    @Value("${api.username}")
    private String username;

    @Value("${api.password}")
    private String password;

    @Value("${api.soho.path.refresh}")
    private String refresh;

    public ResponseEntity<String> authenticate() {
        try {
            String credentials = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Basic " + credentials);
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> request = new HttpEntity<>(headers);

            System.out.println("test0 : " + request);
            System.out.println("test1 : " + String.class);
            System.out.println("test1.2 : " + apiUrl+authUrl);

            ResponseEntity<String> response = new RestTemplate().exchange("https://test2.1cb.kz/soho-v2/v1/login", HttpMethod.POST, request, String.class);
            System.out.println("test2 : " + response);

            if (response.getStatusCode() == HttpStatus.OK) {
                return response;
            } else if (response.getStatusCode() == HttpStatus.UNAUTHORIZED) {
                String errorResponse = response.getBody();
                return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
            } else {
                return new ResponseEntity<>("Ошибка сервера", HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Внутренняя ошибка сервера", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    public ResponseEntity<String> refreshTokens(String refreshToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Создание тела запроса с refresh token
        String requestBody = "{\"token_hash\": \"" + refreshToken + "\"}";

        // Создание запроса с заголовками и телом
        HttpEntity<String> request = new HttpEntity<>(requestBody, headers);

        // Выполнение POST-запроса для обновления токенов
        ResponseEntity<String> response = new RestTemplate().postForEntity(apiUrl+refresh, request, String.class);

        return response;
    }

}

