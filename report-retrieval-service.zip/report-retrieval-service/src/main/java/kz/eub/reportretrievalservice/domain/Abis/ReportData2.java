package kz.eub.reportretrievalservice.domain.Abis;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class ReportData2 {
    private String group;
    private String code;
    private String name;


}
