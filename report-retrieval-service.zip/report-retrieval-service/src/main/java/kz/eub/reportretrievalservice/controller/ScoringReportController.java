package kz.eub.reportretrievalservice.controller;


import io.swagger.v3.oas.annotations.Operation;
import kz.eub.reportretrievalservice.service.ScoringReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequiredArgsConstructor
public class ScoringReportController {

    private final ScoringReportService scoringReportService;

    @PostMapping(path = "/soho", produces = "application/json;charset=utf8")
    @Operation(tags = "Интеграционных сервисов по получению скоринга")
    public ResponseEntity<Object> getScoring(@RequestParam("bin") String bin) {
        log.info("started Integration services for scoring data retrieval");
        if (bin.length() != 12) {
            return new ResponseEntity<>("Error: The length of the bin is not 12", HttpStatus.BAD_REQUEST);
        }
        try {
            ResponseEntity<String> resp = scoringReportService.getScoringData(bin);
            return new ResponseEntity<>(resp.getBody(), resp.getStatusCode());
        } catch (Exception e) {
            return new ResponseEntity<>("Не успешно: данные не доставлены", HttpStatus.BAD_REQUEST);
        }

    }

}
