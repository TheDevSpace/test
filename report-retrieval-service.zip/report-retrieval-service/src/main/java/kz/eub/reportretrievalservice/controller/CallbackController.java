package kz.eub.reportretrievalservice.controller;


import io.swagger.v3.oas.annotations.Operation;
import kz.eub.reportretrievalservice.service.CallbackReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/v1/callback")
public class CallbackController {

    private final CallbackReportService callbackReportService;

    @Operation(tags = "Callback со статусом готовности отчета (status)")
    @PostMapping("/report/status")
    public ResponseEntity<String> handleCallback(
            @RequestParam("product_code") String productCode,
            @RequestParam("bin") String bin,
            @RequestParam("report_id") int reportId,
            @RequestParam("status") String status) {

        log.info("Received report callback: ");
        return callbackReportService.handleCallback(productCode, bin, reportId, status);
    }


}
